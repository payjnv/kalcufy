"use client";
/**
 * RESULTS CARD V4 — Design C
 *
 * Same pattern for ALL calculators:
 * 1. Big number left-aligned
 * 2. Gauge bar (optional — if calculate() returns zones)
 * 3. 3-column grid of secondary results
 * 4. 💡 Insight card with human-friendly text (or summary fallback)
 *
 * No RadialProgress, no composition bars, no metrics list.
 * One clean pattern. Backwards compatible.
 *
 * Bug fix: Removed isCurrencyField auto-detection
 */

import { useCurrency } from "@/lib/currency-helper";
import { translateText } from "@/engine/v4/utils/common-translations";

/* ═══════════════════════════════════════════════════════════════
   TYPES
   ═══════════════════════════════════════════════════════════════ */

interface ResultConfig {
  id: string;
  label: string;
  type: "primary" | "secondary";
  format?: "number" | "currency" | "percentage" | "text" | "date";
  suffix?: string;
  prefix?: string;
  icon?: string;
  tooltip?: string;
}

interface Zone {
  start: number;
  end: number;
  label: string;
  color: string;
}

interface CalculatorResults {
  values: Record<string, unknown>;
  formatted: Record<string, string>;
  summary?: string;
  isValid?: boolean;
  zones?: Zone[];
  gaugeValue?: number;
  gaugeMin?: number;
  gaugeMax?: number;
  insight?: string;
  metadata?: { tableData?: Array<Record<string, string | number>>; [key: string]: unknown };
  // Keep these in the type so old code doesn't break, but we ignore them
  composition?: unknown;
  context?: unknown;
  metrics?: unknown;
}

interface ResultsCardV4Props {
  results: CalculatorResults | null;
  resultConfigs: ResultConfig[];
  hasCalculated: boolean;
  t: (key: string, fallback?: string) => string;
  locale?: string;
  title?: string;
  tooltips?: Record<string, string>;
  isCalculating?: boolean;
}

/* ═══════════════════════════════════════════════════════════════
   GAUGE BAR — Colored zones with marker dot
   ═══════════════════════════════════════════════════════════════ */

function GaugeBar({
  value, min, max, zones, t,
}: {
  value: number; min: number; max: number; zones: Zone[];
  t: (key: string, fallback?: string) => string;
}) {
  const pct = Math.min(100, Math.max(0, ((value - min) / (max - min)) * 100));
  const activeZone = zones.find((z) => value >= z.start && value < z.end) || zones[zones.length - 1];

  return (
    <div className="w-full">
      <div className="relative h-2.5 rounded-full overflow-hidden bg-slate-100">
        {zones.map((zone, i) => {
          const left = ((zone.start - min) / (max - min)) * 100;
          const width = ((zone.end - zone.start) / (max - min)) * 100;
          return (
            <div key={i} className="absolute top-0 h-full"
              style={{ left: `${left}%`, width: `${width}%`, backgroundColor: zone.color, opacity: 0.18 }} />
          );
        })}
        <div className="absolute top-0 left-0 h-full rounded-full transition-all duration-700 ease-out"
          style={{ width: `${pct}%`, backgroundColor: activeZone.color }} />
        <div className="absolute top-1/2 w-3.5 h-3.5 rounded-full border-2 border-white shadow-md transition-all duration-700 ease-out"
          style={{ left: `${pct}%`, transform: "translate(-50%, -50%)", backgroundColor: activeZone.color }} />
      </div>
      <div className="flex justify-between mt-1.5 px-0.5">
        {zones.map((zone, i) => (
          <span key={i} className="text-[10px] font-semibold tracking-wide"
            style={{ color: zone.color, opacity: value >= zone.start && value < zone.end ? 1 : 0.3 }}>
            {t(`values.${zone.label}`, zone.label)}
          </span>
        ))}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   MAIN RESULTS CARD
   ═══════════════════════════════════════════════════════════════ */

export default function ResultsCardV4({
  results, resultConfigs, hasCalculated, t, locale = "en", title, tooltips = {}, isCalculating = false,
}: ResultsCardV4Props) {
  const { format: formatCurrency } = useCurrency();
  const translate = typeof t === "function" ? t : (key: string, fallback?: string) => fallback || key;

  /* ─── Empty state ─── */
  if (!results || !hasCalculated) {
    return (
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
        <div className="text-center text-slate-400 py-8">
          <div className="text-4xl mb-2">📊</div>
          <p>{translate("results.enterValues", "Enter values to see results")}</p>
        </div>
      </div>
    );
  }

  /* ─── Data ─── */
  const primaryResult = resultConfigs.find((r) => r.type === "primary");
  const secondaryResults = resultConfigs.filter((r) => r.type === "secondary");
  const hasZones = !!(results.zones?.length && results.gaugeValue !== undefined);
  const hasInsight = !!results.insight;

  const formatValue = (value: unknown, config: ResultConfig): string => {
    if (value === null || value === undefined) return "--";
    if (results.formatted?.[config.id]) return results.formatted[config.id];
    if (typeof value === "string") return value;
    const num = Number(value);
    if (isNaN(num)) return String(value);
    switch (config.format) {
      case "currency": return formatCurrency(num, { decimals: 2 });
      case "percentage": return `${num.toFixed(2)}%`;
      case "date": case "text": return String(value);
      default:
        if (Math.abs(num) >= 1000) return num.toLocaleString("en-US", { maximumFractionDigits: 2 });
        return num % 1 === 0 ? String(num) : num.toFixed(2);
    }
  };

  const getTranslatedSummary = (): string => {
    if (!results.summary) return "";
    const tpl = translate("summaryTemplate", "");
    if (tpl && tpl !== "summaryTemplate" && tpl !== "") {
      let s = tpl;
      for (const [k, v] of Object.entries(results.formatted)) s = s.replace(new RegExp(`{{${k}}}`, "g"), v);
      for (const [k, v] of Object.entries(results.values)) s = s.replace(new RegExp(`{{${k}}}`, "g"), String(v));
      return s;
    }
    return translateText(results.summary, locale);
  };

  const primaryValue = primaryResult ? formatValue(results.values[primaryResult.id], primaryResult) : "--";
  const translatedSummary = getTranslatedSummary();

  /* ─── Split primary value and unit for display ─── */
  const splitPrimary = (val: string): { number: string; unit: string } => {
    // Try to split "28.3%" → "28.3" + "%"
    // Or "$1,687" → "$1,687" + ""
    // Or "2,284 cal" → "2,284" + "cal"
    const match = val.match(/^([\$€£]?[\d,.-]+)(\s*(.+))?$/);
    if (match) return { number: match[1], unit: match[3] || "" };
    return { number: val, unit: "" };
  };

  const primary = splitPrimary(primaryValue);

  /* ═══════════════════════════════════════════════════════════════
     RENDER — Same layout for ALL calculators
     ═══════════════════════════════════════════════════════════════ */
  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
      {/* 1. Primary Result — left aligned, big */}
      {primaryResult && (
        <div className="p-5 pb-4">
          <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider mb-1">
            {translate(`results.${primaryResult.id}`, primaryResult.label)}
          </p>
          <div className="flex items-baseline gap-1.5">
            <p className="text-5xl font-bold text-slate-900">{primary.number}</p>
            {primary.unit && (
              <p className="text-5xl font-bold text-slate-400">{primary.unit}</p>
            )}
          </div>

          {/* 2. Gauge bar (optional) */}
          {hasZones && (
            <div className="mt-3">
              <GaugeBar
                value={results.gaugeValue!}
                min={results.gaugeMin ?? results.zones![0].start}
                max={results.gaugeMax ?? results.zones![results.zones!.length - 1].end}
                zones={results.zones!}
                t={translate}
              />
            </div>
          )}
        </div>
      )}

      {/* 3. Secondary Results — 3-column grid */}
      {secondaryResults.length > 0 && (
        <div className="px-5 pb-4">
          <div className={`grid gap-2 ${
            secondaryResults.length === 1 ? "grid-cols-1" :
            secondaryResults.length === 2 ? "grid-cols-2" :
            "grid-cols-3"
          }`}>
            {secondaryResults.filter((config) => {
              const fv = results.formatted?.[config.id];
              return fv !== undefined && fv !== null && fv !== "";
            }).map((config) => {
              const value = formatValue(results.values[config.id], config);
              return (
                <div key={config.id} className="bg-slate-50 rounded-xl p-3">
                  <p className="text-[10px] text-slate-400 font-medium mb-0.5">
                    {translate(`results.${config.id}`, config.label)}
                  </p>
                  <p className="text-base font-bold text-slate-800">{value}</p>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 4. Insight 💡 or Summary fallback */}
      {hasInsight ? (
        <div className="px-5 pb-5">
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-4 border border-blue-100/80">
            <div className="flex gap-3">
              <span className="text-lg flex-shrink-0">💡</span>
              <p className="text-[13px] text-slate-700 leading-relaxed">{results.insight}</p>
            </div>
          </div>
        </div>
      ) : translatedSummary ? (
        <div className="px-5 pb-5">
          <div className="bg-blue-50 rounded-xl p-3.5">
            <p className="text-xs text-blue-700 leading-relaxed">{translatedSummary}</p>
          </div>
        </div>
      ) : null}
    </div>
  );
}
