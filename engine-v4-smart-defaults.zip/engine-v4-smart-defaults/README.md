# Engine V4 - Smart Defaults Update

## Cambios Realizados

### 1. `components/InputCardV4.tsx`
- **Estado `touched`**: Nuevo estado que rastrea qué campos han sido tocados por el usuario
- **`handleFieldBlur`**: Nueva función que marca campos como "touched" al salir
- **`validateInput`**: Actualizada para manejar null/empty correctamente
  - Campos vacíos (no requeridos) son válidos - sin errores de min/max
  - Errores solo se muestran después de que el campo es "touched"
- **`NumberInput`**: 
  - Muestra campo vacío cuando valor es null (antes: "0")
  - No fuerza valor default al perder foco si el campo está vacío
  - Soporte para placeholder con estilos
- **`CurrencyInput`**: Mismos cambios que NumberInput
- **`PercentageInput`**: Mismos cambios que NumberInput
- **`SliderInput`**: Agregado onBlur para marcar como touched

### 2. `CalculatorEngineV4.tsx`
- **`initializeValues`**: 
  - Respeta `null` explícito como valor válido (campo vacío)
  - Usa `'defaultValue' in input` para detectar si está definido
  - null = "mostrar campo vacío con placeholder"

### 3. `types/engine.types.ts`
- **`InputConfig.defaultValue`**: Agregado `| null` al tipo
- **`InputConfig.placeholder`**: Documentado para Smart Defaults

## Instalación

```bash
# Desde la raíz del proyecto Kalcufy
cp engine-v4-smart-defaults/components/InputCardV4.tsx src/engine/v4/components/
cp engine-v4-smart-defaults/CalculatorEngineV4.tsx src/engine/v4/
cp engine-v4-smart-defaults/types/engine.types.ts src/engine/v4/types/

# Limpiar cache y reiniciar
rm -rf .next
npm run dev
```

## Uso en Calculadoras

### Campos con Smart Defaults (vacíos + placeholder)

```typescript
// Campos sensibles: mostrar vacío con placeholder
{
  id: "weightLbs",
  type: "number",
  defaultValue: null,      // ← Muestra campo vacío
  placeholder: "180",      // ← Hint visual
  min: 90,
  max: 450,
  suffix: "lbs",
  showWhen: { field: "unitSystem", value: "imperial" },
},
```

### Campos con valor pre-llenado (no sensibles)

```typescript
// Campos no sensibles: pre-llenar con valor razonable
{
  id: "activityLevel",
  type: "select",
  defaultValue: "moderatelyActive",  // ← Pre-seleccionado
  options: [
    { value: "sedentary" },
    { value: "lightlyActive" },
    { value: "moderatelyActive" },
    { value: "veryActive" },
    { value: "extraActive" },
  ],
},
```

## Comportamiento

| Escenario | Antes | Después |
|-----------|-------|---------|
| `defaultValue: null` | Mostraba "0" | Muestra campo vacío |
| Campo vacío al cargar | Error de validación | Sin error (hasta tocarlo) |
| Usuario sale de campo vacío | Forzaba valor default | Mantiene vacío |
| Placeholder | No visible si value="0" | Visible cuando vacío |

## Validación

La validación ahora es "lazy" (solo después de interacción):

1. **Carga inicial**: Sin errores, aunque campos estén vacíos
2. **Usuario toca campo y sale**: Si vacío y requerido → error
3. **Usuario escribe valor inválido**: Error de min/max
4. **Campo no requerido vacío**: Siempre válido

## Compatibilidad

- ✅ Compatible con calculadoras V4 existentes
- ✅ Calculadoras sin `placeholder` siguen funcionando igual
- ✅ Presets siguen llenando todos los valores
- ✅ No requiere cambios en calculadoras existentes

## Traducciones Automáticas de Validación

El engine ahora incluye mensajes de validación humanizados en 4 idiomas:

| Mensaje | English | Español | Português | Français |
|---------|---------|---------|-----------|----------|
| Campo requerido | Please enter a value | Por favor ingresa un valor | Por favor insira um valor | Veuillez entrer une valeur |
| Mínimo (%) | Enter 5% or higher | Ingresa 5% o más | Insira 5% ou mais | Entrez 5% ou plus |
| Máximo | Maximum is 100 | El máximo es 100 | O máximo é 100 | Le maximum est 100 |
| Número inválido | Please enter a valid number | Por favor ingresa un número válido | Por favor insira um número válido | Veuillez entrer un nombre valide |

**¡No necesitas agregar nada a tus calculadoras!** Los mensajes se muestran automáticamente en el idioma correcto según el locale.
