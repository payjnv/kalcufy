# Traducciones de Validación para Engine V4

Cada calculadora V4 debe incluir estas traducciones en su sección `t`:

## Inglés (t.en)
```typescript
validation: {
  required: "Please enter a value",
  invalidNumber: "Please enter a valid number",
  minNumber: "Enter {min} or more",
  maxNumber: "Maximum is {max}",
  minPercent: "Enter {min}% or higher",
  maxPercent: "Enter {max}% or less",
  minCurrency: "Enter at least {min}",
  maxCurrency: "Maximum is {max}",
},
```

## Español (t.es)
```typescript
validation: {
  required: "Por favor ingresa un valor",
  invalidNumber: "Por favor ingresa un número válido",
  minNumber: "Ingresa {min} o más",
  maxNumber: "El máximo es {max}",
  minPercent: "Ingresa {min}% o más",
  maxPercent: "Ingresa {max}% o menos",
  minCurrency: "Ingresa al menos {min}",
  maxCurrency: "El máximo es {max}",
},
```

## Portugués (t.pt)
```typescript
validation: {
  required: "Por favor insira um valor",
  invalidNumber: "Por favor insira um número válido",
  minNumber: "Insira {min} ou mais",
  maxNumber: "O máximo é {max}",
  minPercent: "Insira {min}% ou mais",
  maxPercent: "Insira {max}% ou menos",
  minCurrency: "Insira pelo menos {min}",
  maxCurrency: "O máximo é {max}",
},
```

## Francés (t.fr)
```typescript
validation: {
  required: "Veuillez entrer une valeur",
  invalidNumber: "Veuillez entrer un nombre valide",
  minNumber: "Entrez {min} ou plus",
  maxNumber: "Le maximum est {max}",
  minPercent: "Entrez {min}% ou plus",
  maxPercent: "Entrez {max}% ou moins",
  minCurrency: "Entrez au moins {min}",
  maxCurrency: "Le maximum est {max}",
},
```
