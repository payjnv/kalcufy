"use client";

/**
 * INPUT CARD V4 - Enhanced Version
 * 
 * Features:
 * - Real-time validation with visual feedback
 * - Example hints below inputs
 * - Improved sliders with gradient colors
 * - Min/Max indicators
 * - Better error states
 */

import { useState, useEffect, useId, useMemo } from "react";
import { useCurrency, CurrencyCode } from "@/lib/currency-helper";

// =============================================================================
// TYPES
// =============================================================================
interface InputOption {
  value: string;
  label: string;
}

interface InputConfig {
  id: string;
  type: "number" | "currency" | "percentage" | "select" | "slider" | "radio" | "date" | "text" | "checkbox";
  label: string;
  required?: boolean;
  defaultValue?: unknown;
  min?: number;
  max?: number;
  step?: number;
  suffix?: string;
  prefix?: string;
  helpText?: string;
  placeholder?: string;
  options?: InputOption[];
  width?: "full" | "half";
  showWhen?: { field: string; value: string | string[] } | Array<{ field: string; value: string | string[] }>;
  unitOptions?: Record<string, { suffix?: string; min?: number; max?: number }>;
  example?: string; // NEW: Example text
}

interface InputGroup {
  id: string;
  title: string;
  inputs?: string[];
  inputIds?: string[];
  defaultExpanded?: boolean;
}

type TranslationFn = (key: string, fallback?: string) => string;

interface InputCardV4Props {
  inputs: InputConfig[];
  inputGroups?: InputGroup[];
  values: Record<string, unknown>;
  units: Record<string, string>;
  unitSystem: "metric" | "imperial";
  errors: Record<string, string>;
  onChange: (id: string, value: unknown) => void;
  onUnitChange: (id: string, unit: string) => void;
  onUnitSystemChange: (system: "metric" | "imperial") => void;
  t: TranslationFn;
  showUnitSystemToggle?: boolean;
  unitSystemOptions?: { value: string; label: string }[];
  currentMode?: string;
  currencyCode?: CurrencyCode;
  locale?: string; // For validation message translations
}

// =============================================================================
// VALIDATION HELPER
// =============================================================================
interface ValidationResult {
  isValid: boolean;
  message?: string;
  type?: 'error' | 'warning' | 'success';
}

// =============================================================================
// DEFAULT VALIDATION TRANSLATIONS - Built-in for all 4 languages
// =============================================================================
const DEFAULT_VALIDATION_MESSAGES: Record<string, Record<string, string>> = {
  en: {
    required: "Please enter a value",
    invalidNumber: "Please enter a valid number",
    minNumber: "Enter {min} or more",
    maxNumber: "Maximum is {max}",
    minPercent: "Enter {min}% or higher",
    maxPercent: "Enter {max}% or less",
    minCurrency: "Enter at least {min}",
    maxCurrency: "Maximum is {max}",
  },
  es: {
    required: "Por favor ingresa un valor",
    invalidNumber: "Por favor ingresa un número válido",
    minNumber: "Ingresa {min} o más",
    maxNumber: "El máximo es {max}",
    minPercent: "Ingresa {min}% o más",
    maxPercent: "Ingresa {max}% o menos",
    minCurrency: "Ingresa al menos {min}",
    maxCurrency: "El máximo es {max}",
  },
  pt: {
    required: "Por favor insira um valor",
    invalidNumber: "Por favor insira um número válido",
    minNumber: "Insira {min} ou mais",
    maxNumber: "O máximo é {max}",
    minPercent: "Insira {min}% ou mais",
    maxPercent: "Insira {max}% ou menos",
    minCurrency: "Insira pelo menos {min}",
    maxCurrency: "O máximo é {max}",
  },
  fr: {
    required: "Veuillez entrer une valeur",
    invalidNumber: "Veuillez entrer un nombre valide",
    minNumber: "Entrez {min} ou plus",
    maxNumber: "Le maximum est {max}",
    minPercent: "Entrez {min}% ou plus",
    maxPercent: "Entrez {max}% ou moins",
    minCurrency: "Entrez au moins {min}",
    maxCurrency: "Le maximum est {max}",
  },
};

function validateInput(value: unknown, input: InputConfig, currencySymbol: string = "$", t?: TranslationFn, locale: string = "en"): ValidationResult {
  // SMART DEFAULTS: Check if field is empty (null, undefined, or empty string)
  const isEmpty = value === undefined || value === null || value === "";
  
  // Get defaults for current locale (fallback to English)
  const defaults = DEFAULT_VALIDATION_MESSAGES[locale] || DEFAULT_VALIDATION_MESSAGES.en;
  
  // Translation helper - uses built-in defaults, can be overridden by calculator
  const msg = (key: string, replacements?: Record<string, string>) => {
    // Try custom t() first, fallback to built-in defaults
    let text = t ? t(`validation.${key}`, defaults[key] || key) : (defaults[key] || key);
    if (replacements) {
      Object.entries(replacements).forEach(([k, v]) => {
        text = text.replace(`{${k}}`, v);
      });
    }
    return text;
  };
  
  // Required check
  if (input.required && isEmpty) {
    return { isValid: false, message: msg("required"), type: 'error' };
  }
  
  // SMART DEFAULTS: If field is empty and not required, it's valid (no min/max check)
  if (isEmpty) {
    return { isValid: true };
  }
  
  // For numeric types, validate the actual number
  if (input.type === "number" || input.type === "currency" || input.type === "percentage" || input.type === "slider") {
    const num = Number(value);
    
    if (isNaN(num)) {
      return { isValid: false, message: msg("invalidNumber"), type: 'error' };
    }
    
    // HUMAN-FRIENDLY ERROR MESSAGES
    if (input.min !== undefined && num < input.min) {
      let message: string;
      if (input.type === "currency") {
        message = msg("minCurrency", { min: `${currencySymbol}${input.min.toLocaleString()}` });
      } else if (input.type === "percentage") {
        message = msg("minPercent", { min: String(input.min) });
      } else {
        const suffix = input.suffix ? ` ${input.suffix}` : '';
        message = msg("minNumber", { min: `${input.min}${suffix}` });
      }
      return { isValid: false, message, type: 'error' };
    }
    
    if (input.max !== undefined && num > input.max) {
      let message: string;
      if (input.type === "currency") {
        message = msg("maxCurrency", { max: `${currencySymbol}${input.max.toLocaleString()}` });
      } else if (input.type === "percentage") {
        message = msg("maxPercent", { max: String(input.max) });
      } else {
        const suffix = input.suffix ? ` ${input.suffix}` : '';
        message = msg("maxNumber", { max: `${input.max}${suffix}` });
      }
      return { isValid: false, message, type: 'error' };
    }
  }
  
  return { isValid: true, type: 'success' };
}

// =============================================================================
// EXAMPLE GENERATOR
// =============================================================================
function generateExample(input: InputConfig, currencySymbol: string = "$"): string | null {
  // If custom example provided, use it
  if (input.example) return input.example;
  
  // Auto-generate based on type and id
  const id = input.id.toLowerCase();
  
  if (input.type === "currency") {
    if (id.includes("price") || id.includes("vehicle") || id.includes("home") || id.includes("property")) {
      return `Example: ${currencySymbol}35,000`;
    }
    if (id.includes("down") || id.includes("payment")) {
      return `Example: ${currencySymbol}5,000`;
    }
    if (id.includes("income") || id.includes("salary")) {
      return `Example: ${currencySymbol}75,000/year`;
    }
    if (id.includes("loan") || id.includes("amount")) {
      return `Example: ${currencySymbol}25,000`;
    }
    return `Example: ${currencySymbol}10,000`;
  }
  
  if (input.type === "percentage") {
    if (id.includes("interest") || id.includes("rate") || id.includes("apr")) {
      return "Example: 6.5% (typical auto loan rate)";
    }
    if (id.includes("down")) {
      return "Example: 20% (recommended minimum)";
    }
    if (id.includes("tax")) {
      return "Example: 6% (varies by state)";
    }
    return "Example: 5%";
  }
  
  if (input.type === "number" || input.type === "slider") {
    if (id.includes("term") || id.includes("month") || id.includes("year")) {
      if (id.includes("year")) return "Example: 5 years";
      return "Example: 60 months (5 years)";
    }
    if (id.includes("age")) {
      return "Example: 30 years old";
    }
    if (id.includes("weight")) {
      return "Example: 150 lbs";
    }
    if (id.includes("height")) {
      return "Example: 5'10\" or 70 inches";
    }
  }
  
  return null;
}

// =============================================================================
// INPUT WRAPPER WITH VALIDATION UI
// =============================================================================
function InputWrapper({ 
  children, 
  validation, 
  example,
  showExample = true 
}: { 
  children: React.ReactNode;
  validation?: ValidationResult;
  example?: string | null;
  showExample?: boolean;
}) {
  return (
    <div className="space-y-1">
      {children}
      
      {/* Validation Message */}
      {validation && !validation.isValid && validation.message && (
        <div className={`flex items-center gap-1.5 text-sm ${
          validation.type === 'error' ? 'text-red-600' : 
          validation.type === 'warning' ? 'text-amber-600' : 'text-slate-500'
        }`}>
          {validation.type === 'error' && (
            <svg className="w-4 h-4 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
            </svg>
          )}
          <span>{validation.message}</span>
        </div>
      )}
      
      {/* Example Hint */}
      {showExample && example && validation?.isValid !== false && (
        <p className="text-xs text-slate-400 flex items-center gap-1">
          <span className="text-slate-300">💡</span>
          {example}
        </p>
      )}
    </div>
  );
}

// =============================================================================
// CURRENCY INPUT - Enhanced
// =============================================================================
function CurrencyInput({ 
  input, 
  value, 
  onChange,
  onBlur: onBlurProp, // SMART DEFAULTS
  errorId, 
  t,
  currencySymbol = "$",
  validation
}: { 
  input: InputConfig; 
  value: number; 
  onChange: (v: number) => void;
  onBlur?: () => void; // SMART DEFAULTS
  errorId?: string; 
  t: TranslationFn;
  currencySymbol?: string;
  validation?: ValidationResult;
}) {
  const label = t("inputs." + input.id + ".label", input.label);
  const minVal = input.min;
  const maxVal = input.max;
  
  // SMART DEFAULTS: Handle null values
  const [displayValue, setDisplayValue] = useState<string>(() => {
    if (value === undefined || value === null || isNaN(value)) return "";
    return formatNumberWithCommas(value);
  });
  const [isFocused, setIsFocused] = useState(false);
  
  function formatNumberWithCommas(num: number): string {
    return num.toLocaleString("en-US", { maximumFractionDigits: 2 });
  }
  
  function parseFormattedNumber(str: string): number {
    return Number(str.replace(/,/g, ""));
  }
  
  useEffect(() => {
    if (!isFocused) {
      // SMART DEFAULTS: Keep empty if null
      if (value === null || value === undefined) {
        setDisplayValue("");
      } else if (!isNaN(value)) {
        setDisplayValue(formatNumberWithCommas(value));
      }
    }
  }, [value, isFocused]);
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value;
    const cleaned = raw.replace(/[^0-9.,]/g, "");
    setDisplayValue(cleaned);
    
    const num = parseFormattedNumber(cleaned);
    if (cleaned !== "" && !isNaN(num)) {
      onChange(num);
    }
  };
  
  const handleBlur = () => {
    setIsFocused(false);
    onBlurProp?.(); // SMART DEFAULTS: Mark as touched
    
    // SMART DEFAULTS: Keep empty if user didn't enter anything
    if (displayValue === "") {
      return;
    }
    
    const num = parseFormattedNumber(displayValue);
    if (isNaN(num)) {
      setDisplayValue("");
      return;
    }
    
    let finalNum = num;
    if (minVal !== undefined && num < minVal) finalNum = minVal;
    if (maxVal !== undefined && num > maxVal) finalNum = maxVal;
    setDisplayValue(formatNumberWithCommas(finalNum));
    onChange(finalNum);
  };
  
  const isError = validation && !validation.isValid;
  const isEmpty = !displayValue || displayValue === "";
  
  // PROFESSIONAL STYLE: Clean, minimal borders
  const borderClass = isError 
    ? "border-2 border-red-400 bg-red-50/50" 
    : isFocused 
    ? "border-2 border-blue-400 bg-white shadow-sm" 
    : "border border-slate-200 bg-white hover:border-slate-300";
  
  const example = generateExample(input, currencySymbol);
  
  return (
    <InputWrapper validation={validation} example={example}>
      <label htmlFor={input.id} className="block font-medium text-slate-700 mb-2">
        {label}
        {input.required && <span className="text-red-500 ml-1" aria-hidden="true">*</span>}
      </label>
      <div className={`relative flex items-center rounded-xl transition-all ${borderClass}`}>
        <span className={`pl-4 shrink-0 ${isError ? 'text-red-400' : 'text-slate-400'}`}>
          {currencySymbol}
        </span>
        <input
          id={input.id}
          type="text"
          inputMode="decimal"
          value={displayValue}
          onChange={handleInputChange}
          onFocus={() => setIsFocused(true)}
          onBlur={handleBlur}
          placeholder={input.placeholder || "0"}
          required={input.required}
          aria-required={input.required}
          aria-invalid={isError}
          aria-describedby={[errorId, input.helpText ? `help-${input.id}` : undefined].filter(Boolean).join(" ") || undefined}
          className="flex-1 min-w-0 bg-transparent px-2 py-3.5 text-slate-800 focus:outline-none placeholder:text-slate-400"
        />
        {/* Quick increment buttons */}
        <div className="flex flex-col border-l border-slate-100 mr-1">
          <button 
            type="button"
            onClick={() => onChange((value || 0) + (input.step || 1000))}
            className="px-2 py-1 text-slate-300 hover:text-blue-500 transition-colors"
            aria-label="Increase value"
          >
            <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 15l7-7 7 7" />
            </svg>
          </button>
          <button 
            type="button"
            onClick={() => onChange(Math.max(0, (value || 0) - (input.step || 1000)))}
            className="px-2 py-1 text-slate-300 hover:text-blue-500 transition-colors"
            aria-label="Decrease value"
          >
            <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
            </svg>
          </button>
        </div>
      </div>
      {input.helpText && (
        <p id={`help-${input.id}`} className="text-sm text-slate-500 mt-1">
          {t("inputs." + input.id + ".helpText", input.helpText)}
        </p>
      )}
    </InputWrapper>
  );
}

// =============================================================================
// PERCENTAGE INPUT - Enhanced
// =============================================================================
function PercentageInput({ 
  input, 
  value, 
  onChange,
  onBlur: onBlurProp, // SMART DEFAULTS
  errorId, 
  t,
  validation
}: { 
  input: InputConfig; 
  value: number; 
  onChange: (v: number) => void;
  onBlur?: () => void; // SMART DEFAULTS
  errorId?: string; 
  t: TranslationFn;
  validation?: ValidationResult;
}) {
  const label = t("inputs." + input.id + ".label", input.label);
  const minVal = input.min ?? 0;
  const maxVal = input.max ?? 100;
  
  // SMART DEFAULTS: Handle null values
  const [displayValue, setDisplayValue] = useState<string>(() => {
    if (value === null || value === undefined) return "";
    return String(value);
  });
  const [isFocused, setIsFocused] = useState(false);
  
  useEffect(() => {
    if (!isFocused) {
      if (value === null || value === undefined) {
        setDisplayValue("");
      } else if (!isNaN(value)) {
        setDisplayValue(String(value));
      }
    }
  }, [value, isFocused]);
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value;
    setDisplayValue(raw);
    const num = Number(raw);
    if (raw !== "" && !isNaN(num)) {
      onChange(num);
    }
  };
  
  const handleBlur = () => {
    setIsFocused(false);
    onBlurProp?.(); // SMART DEFAULTS: Mark as touched
    
    if (displayValue === "") {
      return;
    }
    
    const num = Number(displayValue);
    if (isNaN(num)) {
      setDisplayValue("");
      return;
    }
    
    let finalNum = num;
    if (num < minVal) finalNum = minVal;
    if (num > maxVal) finalNum = maxVal;
    setDisplayValue(String(finalNum));
    onChange(finalNum);
  };
  
  const isError = validation && !validation.isValid;
  const isEmpty = !displayValue || displayValue === "";
  
  // PROFESSIONAL STYLE: Clean, minimal borders
  const borderClass = isError 
    ? "border-2 border-red-400 bg-red-50/50" 
    : isFocused 
    ? "border-2 border-blue-400 bg-white shadow-sm" 
    : "border border-slate-200 bg-white hover:border-slate-300";
  
  const example = generateExample(input);
  
  return (
    <InputWrapper validation={validation} example={example}>
      <label htmlFor={input.id} className="block font-medium text-slate-700 mb-2">
        {label}
        {input.required && <span className="text-red-500 ml-1" aria-hidden="true">*</span>}
      </label>
      <div className={`relative flex items-center rounded-xl transition-all ${borderClass}`}>
        <input
          id={input.id}
          type="text"
          inputMode="decimal"
          value={displayValue}
          onChange={handleInputChange}
          onFocus={() => setIsFocused(true)}
          onBlur={handleBlur}
          placeholder={input.placeholder || ""}
          required={input.required}
          aria-required={input.required}
          aria-invalid={isError}
          className="flex-1 min-w-0 bg-transparent px-4 py-3.5 text-slate-800 focus:outline-none placeholder:text-slate-400"
        />
        <span className={`pr-4 shrink-0 ${isError ? 'text-red-400' : 'text-slate-400'}`}>
          %
        </span>
      </div>
      {input.helpText && (
        <p id={`help-${input.id}`} className="text-sm text-slate-500 mt-1">
          {t("inputs." + input.id + ".helpText", input.helpText)}
        </p>
      )}
    </InputWrapper>
  );
}

// =============================================================================
// SLIDER INPUT - Enhanced with gradient
// =============================================================================
function SliderInput({ 
  input, 
  value, 
  onChange,
  onBlur: onBlurProp, // SMART DEFAULTS
  errorId, 
  t, 
  unitSystem,
  validation,
  currencySymbol = "$"
}: { 
  input: InputConfig; 
  value: number; 
  onChange: (v: number) => void;
  onBlur?: () => void; // SMART DEFAULTS
  errorId?: string; 
  t: TranslationFn; 
  unitSystem?: "metric" | "imperial";
  validation?: ValidationResult;
  currencySymbol?: string;
}) {
  const label = t("inputs." + input.id + ".label", input.label);
  
  const unitOpts = input.unitOptions;
  const currentUnitOpts = unitOpts && unitSystem ? unitOpts[unitSystem] : null;
  const suffix = currentUnitOpts?.suffix 
    ? t("inputs." + input.id + ".suffix", currentUnitOpts.suffix) 
    : (input.suffix ? t("inputs." + input.id + ".suffix", input.suffix) : "");
  
  const prefix = input.prefix ? t("inputs." + input.id + ".prefix", input.prefix) : "";
  
  const minVal = currentUnitOpts?.min ?? input.min ?? 0;
  const maxVal = currentUnitOpts?.max ?? input.max ?? 100;
  
  // SMART DEFAULTS: Sliders need a value, use min or placeholder as fallback
  const effectiveValue = (value !== null && value !== undefined) ? value : minVal;
  const [displayValue, setDisplayValue] = useState<string>(() => String(effectiveValue));
  const [isFocused, setIsFocused] = useState(false);
  
  useEffect(() => {
    if (!isFocused) {
      const val = (value !== null && value !== undefined) ? value : minVal;
      if (!isNaN(val)) {
        setDisplayValue(String(val));
      }
    }
  }, [value, isFocused, minVal]);
  
  const handleTextChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value;
    setDisplayValue(raw);
    const num = Number(raw);
    if (raw !== "" && !isNaN(num)) {
      onChange(num);
    }
  };
  
  const handleTextBlur = () => {
    setIsFocused(false);
    onBlurProp?.(); // SMART DEFAULTS: Mark as touched
    
    const num = Number(displayValue);
    if (displayValue === "" || isNaN(num)) {
      const defaultVal = (input.defaultValue as number) ?? minVal;
      setDisplayValue(String(defaultVal));
      onChange(defaultVal);
    } else {
      let finalNum = num;
      if (num < minVal) finalNum = minVal;
      if (num > maxVal) finalNum = maxVal;
      setDisplayValue(String(finalNum));
      onChange(finalNum);
    }
  };
  
  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const num = Number(e.target.value);
    setDisplayValue(String(num));
    onChange(num);
    onBlurProp?.(); // SMART DEFAULTS: Mark as touched when slider moves
  };
  
  // Calculate progress percentage for gradient
  const progress = ((effectiveValue) - minVal) / (maxVal - minVal) * 100;
  
  const example = generateExample(input, currencySymbol);
  
  return (
    <InputWrapper validation={validation} example={example}>
      <div role="group" aria-labelledby={"label-" + input.id}>
        <div className="flex justify-between items-center mb-3">
          <label id={"label-" + input.id} htmlFor={input.id} className="font-medium text-slate-700">
            {label}
            {input.required && <span className="text-red-500 ml-1" aria-hidden="true">*</span>}
          </label>
          <div className="flex items-center bg-blue-50 border border-blue-200 rounded-lg px-3 py-1.5">
            {prefix && <span className="text-blue-600 mr-1 font-medium">{prefix}</span>}
            <input
              type="text"
              inputMode="numeric"
              value={displayValue}
              onChange={handleTextChange}
              onFocus={() => setIsFocused(true)}
              onBlur={handleTextBlur}
              aria-label={label + " value"}
              className="w-16 text-right bg-transparent font-bold text-blue-600 focus:outline-none"
            />
            {suffix && <span className="text-blue-600 ml-1 font-medium">{suffix}</span>}
          </div>
        </div>
        
        {/* Custom slider with gradient */}
        <div className="relative">
          <div className="absolute top-1/2 left-0 right-0 h-2 -translate-y-1/2 rounded-full bg-slate-200 overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-blue-400 to-blue-600 transition-all duration-150"
              style={{ width: `${progress}%` }}
            />
          </div>
          <input
            id={input.id}
            type="range"
            min={minVal}
            max={maxVal}
            step={input.step || 1}
            value={value ?? minVal}
            onChange={handleSliderChange}
            aria-valuemin={minVal}
            aria-valuemax={maxVal}
            aria-valuenow={value ?? minVal}
            aria-valuetext={prefix + (value ?? minVal) + " " + suffix}
            className="relative w-full h-6 appearance-none bg-transparent cursor-pointer z-20
              [&::-webkit-slider-thumb]:appearance-none
              [&::-webkit-slider-thumb]:w-5
              [&::-webkit-slider-thumb]:h-5
              [&::-webkit-slider-thumb]:rounded-full
              [&::-webkit-slider-thumb]:bg-white
              [&::-webkit-slider-thumb]:border-2
              [&::-webkit-slider-thumb]:border-blue-600
              [&::-webkit-slider-thumb]:shadow-lg
              [&::-webkit-slider-thumb]:cursor-pointer
              [&::-webkit-slider-thumb]:transition-transform
              [&::-webkit-slider-thumb]:hover:scale-110
              [&::-moz-range-thumb]:w-5
              [&::-moz-range-thumb]:h-5
              [&::-moz-range-thumb]:rounded-full
              [&::-moz-range-thumb]:bg-white
              [&::-moz-range-thumb]:border-2
              [&::-moz-range-thumb]:border-blue-600
              [&::-moz-range-thumb]:shadow-lg
              [&::-moz-range-thumb]:cursor-pointer"
          />
        </div>
        
        <div className="flex justify-between text-xs text-slate-400 mt-2" aria-hidden="true">
          <span className="bg-slate-100 px-2 py-0.5 rounded">{prefix}{minVal.toLocaleString()}{suffix}</span>
          <span className="bg-slate-100 px-2 py-0.5 rounded">{prefix}{maxVal.toLocaleString()}{suffix}</span>
        </div>
        
        {input.helpText && (
          <p className="text-sm text-slate-500 mt-2">
            {t("inputs." + input.id + ".helpText", input.helpText)}
          </p>
        )}
      </div>
    </InputWrapper>
  );
}

// =============================================================================
// NUMBER INPUT - Enhanced
// =============================================================================
function NumberInput({ 
  input, 
  value, 
  onChange,
  onBlur: onBlurProp, // SMART DEFAULTS: External blur handler
  errorId, 
  t, 
  unitSystem,
  validation,
  currencySymbol = "$"
}: { 
  input: InputConfig; 
  value: number; 
  onChange: (v: number) => void;
  onBlur?: () => void; // SMART DEFAULTS
  errorId?: string; 
  t: TranslationFn; 
  unitSystem?: "metric" | "imperial";
  validation?: ValidationResult;
  currencySymbol?: string;
}) {
  const label = t("inputs." + input.id + ".label", input.label);
  
  const unitOpts = input.unitOptions;
  const currentUnitOpts = unitOpts && unitSystem ? unitOpts[unitSystem] : null;
  const suffix = currentUnitOpts?.suffix 
    ? t("inputs." + input.id + ".suffix", currentUnitOpts.suffix) 
    : (input.suffix ? t("inputs." + input.id + ".suffix", input.suffix) : "");
  
  const prefix = input.prefix ? t("inputs." + input.id + ".prefix", input.prefix) : "";
  
  const minVal = currentUnitOpts?.min ?? input.min;
  const maxVal = currentUnitOpts?.max ?? input.max;
  
  // SMART DEFAULTS: Handle null values - show empty string instead of "0"
  const [displayValue, setDisplayValue] = useState<string>(() => {
    if (value === null || value === undefined) return "";
    return String(value);
  });
  const [isFocused, setIsFocused] = useState(false);
  
  useEffect(() => {
    if (!isFocused) {
      // SMART DEFAULTS: Keep empty if null
      if (value === null || value === undefined) {
        setDisplayValue("");
      } else if (!isNaN(value)) {
        setDisplayValue(String(value));
      }
    }
  }, [value, isFocused]);
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value;
    setDisplayValue(raw);
    const num = Number(raw);
    if (raw !== "" && !isNaN(num)) {
      onChange(num);
    }
  };
  
  const handleBlur = () => {
    setIsFocused(false);
    onBlurProp?.(); // SMART DEFAULTS: Call external blur handler to mark as touched
    
    const num = Number(displayValue);
    
    // SMART DEFAULTS: If field is empty and has placeholder, keep it empty (null)
    // Don't force a default value
    if (displayValue === "") {
      // Keep empty - validation will show error if touched
      return;
    }
    
    if (isNaN(num)) {
      // Invalid input - clear it
      setDisplayValue("");
      return;
    }
    
    // Clamp to min/max if needed
    let finalNum = num;
    if (minVal !== undefined && num < minVal) finalNum = minVal;
    if (maxVal !== undefined && num > maxVal) finalNum = maxVal;
    setDisplayValue(String(finalNum));
    onChange(finalNum);
  };
  
  const isError = validation && !validation.isValid;
  const isEmpty = !displayValue || displayValue === "";
  
  // PROFESSIONAL STYLE: Clean, minimal borders
  const borderClass = isError 
    ? "border-2 border-red-400 bg-red-50/50" 
    : isFocused 
    ? "border-2 border-blue-400 bg-white shadow-sm" 
    : "border border-slate-200 bg-white hover:border-slate-300";
  
  const example = generateExample(input, currencySymbol);
  
  return (
    <InputWrapper validation={validation} example={example}>
      <label htmlFor={input.id} className="block font-medium text-slate-700 mb-2">
        {label}
        {input.required && <span className="text-red-500 ml-1" aria-hidden="true">*</span>}
      </label>
      <div className={`relative flex items-center rounded-xl transition-all ${borderClass}`}>
        {prefix && <span className="pl-4 text-slate-400 shrink-0">{prefix}</span>}
        <input
          id={input.id}
          type="text"
          inputMode="decimal"
          value={displayValue}
          onChange={handleInputChange}
          onFocus={() => setIsFocused(true)}
          onBlur={handleBlur}
          placeholder={input.placeholder || ""} 
          required={input.required}
          aria-required={input.required}
          aria-invalid={isError}
          aria-describedby={[errorId, input.helpText ? `help-${input.id}` : undefined].filter(Boolean).join(" ") || undefined}
          className="flex-1 min-w-0 bg-transparent px-4 py-3.5 text-slate-800 focus:outline-none placeholder:text-slate-400"
        />
        {suffix && <span className="pr-4 shrink-0 text-slate-400">{suffix}</span>}
      </div>
      {input.helpText && (
        <p id={`help-${input.id}`} className="text-sm text-slate-500 mt-1">
          {t("inputs." + input.id + ".helpText", input.helpText)}
        </p>
      )}
    </InputWrapper>
  );
}

// =============================================================================
// SELECT INPUT - Enhanced
// =============================================================================
function SelectInput({ input, value, onChange, errorId, t }: { input: InputConfig; value: string; onChange: (v: string) => void; errorId?: string; t: TranslationFn }) {
  const options = input.options || [];
  const label = t("inputs." + input.id + ".label", input.label);
  const [isFocused, setIsFocused] = useState(false);
  
  // PROFESSIONAL STYLE
  const borderClass = isFocused 
    ? "border-2 border-blue-400 bg-white shadow-sm" 
    : "border border-slate-200 bg-white hover:border-slate-300";
  
  return (
    <div>
      <label htmlFor={input.id} className="block font-medium text-slate-700 mb-2">
        {label}
        {input.required && <span className="text-red-500 ml-1" aria-hidden="true">*</span>}
      </label>
      <div className="relative">
        <select
          id={input.id}
          value={value || input.defaultValue || ""}
          onChange={(e) => onChange(e.target.value)}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          required={input.required}
          aria-required={input.required}
          aria-invalid={!!errorId}
          aria-describedby={errorId}
          className={`w-full rounded-xl px-4 py-3.5 pr-10 text-slate-800 focus:outline-none appearance-none cursor-pointer transition-all ${borderClass}`}
        >
          {options.map((opt) => (
            <option key={opt.value} value={opt.value}>
              {t("inputs." + input.id + ".options." + opt.value, opt.label)}
            </option>
          ))}
        </select>
        <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
          <svg className="w-5 h-5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </div>
      </div>
    </div>
  );
}

// =============================================================================
// RADIO INPUT - Enhanced with cards style
// =============================================================================
function RadioInput({ input, value, onChange, errorId, t }: { input: InputConfig; value: string; onChange: (v: string) => void; errorId?: string; t: TranslationFn }) {
  const options = input.options || [];
  const label = t("inputs." + input.id + ".label", input.label);
  const groupId = useId();
  
  return (
    <fieldset role="radiogroup" aria-labelledby={groupId}>
      <legend id={groupId} className="block font-medium text-slate-700 mb-2">
        {label}
        {input.required && <span className="text-red-500 ml-1" aria-hidden="true">*</span>}
      </legend>
      <div className="grid grid-cols-2 gap-2">
        {options.map((opt) => {
          const isSelected = value === opt.value;
          return (
            <button
              key={opt.value}
              type="button"
              role="radio"
              aria-checked={isSelected}
              onClick={() => onChange(opt.value)}
              className={`py-3 px-4 rounded-xl text-sm font-medium transition-all focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-1 ${
                isSelected
                  ? "bg-blue-600 text-white shadow-sm border-2 border-blue-600"
                  : "bg-white text-slate-600 border border-slate-200 hover:border-slate-300 hover:bg-slate-50"
              }`}
            >
              {t("inputs." + input.id + ".options." + opt.value, opt.label)}
            </button>
          );
        })}
      </div>
    </fieldset>
  );
}

// =============================================================================
// DATE INPUT
// =============================================================================
function DateInput({ input, value, onChange, errorId, t }: { input: InputConfig; value: string; onChange: (v: string) => void; errorId?: string; t: TranslationFn }) {
  const label = t("inputs." + input.id + ".label", input.label);
  const [isFocused, setIsFocused] = useState(false);
  
  // PROFESSIONAL STYLE
  const borderClass = isFocused 
    ? "border-2 border-blue-400 bg-white shadow-sm" 
    : "border border-slate-200 bg-white hover:border-slate-300";
  
  return (
    <div>
      <label htmlFor={input.id} className="block font-medium text-slate-700 mb-2">
        {label}
        {input.required && <span className="text-red-500 ml-1" aria-hidden="true">*</span>}
      </label>
      <input
        id={input.id}
        type="date"
        value={value || ""}
        onChange={(e) => onChange(e.target.value)}
        onFocus={() => setIsFocused(true)}
        onBlur={() => setIsFocused(false)}
        required={input.required}
        aria-required={input.required}
        aria-invalid={!!errorId}
        className={`w-full rounded-xl px-4 py-3.5 text-slate-800 focus:outline-none transition-all ${borderClass}`}
      />
    </div>
  );
}

// =============================================================================
// TEXT INPUT
// =============================================================================
function TextInput({ input, value, onChange, errorId, t }: { input: InputConfig; value: string; onChange: (v: string) => void; errorId?: string; t: TranslationFn }) {
  const label = t("inputs." + input.id + ".label", input.label);
  const [isFocused, setIsFocused] = useState(false);
  
  // PROFESSIONAL STYLE
  const borderClass = isFocused 
    ? "border-2 border-blue-400 bg-white shadow-sm" 
    : "border border-slate-200 bg-white hover:border-slate-300";
  
  return (
    <div>
      <label htmlFor={input.id} className="block font-medium text-slate-700 mb-2">
        {label}
        {input.required && <span className="text-red-500 ml-1" aria-hidden="true">*</span>}
      </label>
      <input
        id={input.id}
        type="text"
        value={value || ""}
        onChange={(e) => onChange(e.target.value)}
        onFocus={() => setIsFocused(true)}
        onBlur={() => setIsFocused(false)}
        placeholder={input.placeholder}
        required={input.required}
        aria-required={input.required}
        aria-invalid={!!errorId}
        className={`w-full rounded-xl px-4 py-3.5 text-slate-800 focus:outline-none transition-all placeholder:text-slate-400 ${borderClass}`}
      />
    </div>
  );
}

// =============================================================================
// CHECKBOX INPUT
// =============================================================================
function CheckboxInput({ input, value, onChange, errorId, t }: { input: InputConfig; value: boolean; onChange: (v: boolean) => void; errorId?: string; t: TranslationFn }) {
  const label = t("inputs." + input.id + ".label", input.label);
  
  return (
    <label className="flex items-center gap-3 cursor-pointer group">
      <div className="relative">
        <input
          id={input.id}
          type="checkbox"
          checked={value || false}
          onChange={(e) => onChange(e.target.checked)}
          className="sr-only peer"
          aria-invalid={!!errorId}
        />
        <div className="w-6 h-6 border-2 border-slate-200 bg-white rounded-lg peer-checked:bg-blue-600 peer-checked:border-blue-600 peer-focus:ring-2 peer-focus:ring-blue-400 peer-focus:ring-offset-1 transition-all group-hover:border-slate-300 peer-checked:group-hover:bg-blue-700 flex items-center justify-center">
          <svg className="w-4 h-4 text-white opacity-0 peer-checked:opacity-100 transition-opacity" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
          </svg>
        </div>
      </div>
      <span className="text-slate-700">{label}</span>
    </label>
  );
}


// =============================================================================
// AUTO-DETECT SLIDER - Converts appropriate fields to sliders automatically
// =============================================================================
function shouldUseSlider(input) {
  const id = input.id.toLowerCase();
  const label = (input.label || '').toLowerCase();
  const combined = id + ' ' + label;
  
  // Fields that should be sliders (for exploration)
  const sliderKeywords = [
    'interest', 'rate', 'apr', 'tae', 'tasa',  // Interest rates
    'term', 'plazo', 'months', 'meses', 'years', 'años', 'anos', // Loan terms
    'duration', 'duracion', 'periodo', 'period',
  ];
  
  // Fields that should NOT be sliders (user knows exact value)
  const noSliderKeywords = [
    'price', 'precio', 'preço',
    'amount', 'monto', 'valor',
    'payment', 'pago', 'pagamento',
    'income', 'salary', 'ingreso', 'salario',
    'fee', 'tarifa', 'taxa',
    'trade', 'intercambio',
  ];
  
  // Check exclusions first
  if (noSliderKeywords.some(kw => combined.includes(kw))) {
    return false;
  }
  
  // Check if should be slider
  return sliderKeywords.some(kw => combined.includes(kw));
}

// Get smart defaults for slider ranges
function getSliderDefaults(input) {
  const id = input.id.toLowerCase();
  const label = (input.label || '').toLowerCase();
  const combined = id + ' ' + label;
  
  // Interest rate fields
  if (combined.includes('interest') || combined.includes('rate') || combined.includes('apr') || combined.includes('tae') || combined.includes('tasa')) {
    return {
      min: input.min ?? 0,
      max: input.max ?? 25,
      step: input.step ?? 0.1,
      suffix: '%'
    };
  }
  
  // Loan term in months
  if (combined.includes('month') || combined.includes('meses')) {
    return {
      min: input.min ?? 12,
      max: input.max ?? 84,
      step: input.step ?? 12,
      suffix: input.suffix || ' months'
    };
  }
  
  // Loan term in years
  if (combined.includes('year') || combined.includes('años') || combined.includes('anos')) {
    return {
      min: input.min ?? 1,
      max: input.max ?? 30,
      step: input.step ?? 1,
      suffix: input.suffix || ' years'
    };
  }
  
  // Generic term/duration
  if (combined.includes('term') || combined.includes('plazo') || combined.includes('duration')) {
    return {
      min: input.min ?? 12,
      max: input.max ?? 84,
      step: input.step ?? 6,
      suffix: input.suffix || ''
    };
  }
  
  return {};
}

// =============================================================================
// RENDER INPUT
// =============================================================================
function RenderInput({ 
  input, 
  value, 
  onChange,
  onBlur, // SMART DEFAULTS: Add onBlur prop
  errorId, 
  t, 
  unitSystem, 
  currencySymbol,
  validation
}: { 
  input: InputConfig; 
  value: unknown; 
  onChange: (v: unknown) => void;
  onBlur?: () => void; // SMART DEFAULTS: Optional blur handler
  errorId?: string; 
  t: TranslationFn; 
  unitSystem?: "metric" | "imperial"; 
  currencySymbol?: string;
  validation?: ValidationResult;
}) {
  // Auto-detect if should be slider
  const useSlider = shouldUseSlider(input);
  const effectiveType = useSlider && (input.type === 'number' || input.type === 'percentage') ? 'slider' : input.type;
  
  // Apply smart defaults for sliders
  const effectiveInput = useSlider ? { ...input, ...getSliderDefaults(input) } : input;
  
  switch (effectiveType) {
    case "currency":
      return <CurrencyInput input={input} value={value as number} onChange={onChange} onBlur={onBlur} errorId={errorId} t={t} currencySymbol={currencySymbol} validation={validation} />;
    case "percentage":
      return <PercentageInput input={input} value={value as number} onChange={onChange} onBlur={onBlur} errorId={errorId} t={t} validation={validation} />;
    case "slider":
      return <SliderInput input={effectiveInput} value={value as number} onChange={onChange} onBlur={onBlur} errorId={errorId} t={t} unitSystem={unitSystem} validation={validation} currencySymbol={currencySymbol} />;
    case "select":
      return <SelectInput input={input} value={value as string} onChange={onChange} errorId={errorId} t={t} />;
    case "radio":
      return <RadioInput input={input} value={value as string} onChange={onChange} errorId={errorId} t={t} />;
    case "date":
      return <DateInput input={input} value={value as string} onChange={onChange} errorId={errorId} t={t} />;
    case "text":
      return <TextInput input={input} value={value as string} onChange={onChange} errorId={errorId} t={t} />;
    case "checkbox":
      return <CheckboxInput input={input} value={value as boolean} onChange={onChange} errorId={errorId} t={t} />;
    default:
      return <NumberInput input={input} value={value as number} onChange={onChange} onBlur={onBlur} errorId={errorId} t={t} unitSystem={unitSystem} validation={validation} currencySymbol={currencySymbol} />;
  }
}

// =============================================================================
// MAIN INPUT CARD V4 COMPONENT
// =============================================================================
export default function InputCardV4({
  inputs,
  inputGroups,
  values,
  units,
  unitSystem,
  errors,
  onChange,
  onUnitChange,
  onUnitSystemChange,
  t,
  showUnitSystemToggle,
  unitSystemOptions,
  currentMode,
  currencyCode,
  locale = "en",
}: InputCardV4Props) {
  const [expandedGroups, setExpandedGroups] = useState<Record<string, boolean>>({});
  const [touched, setTouched] = useState<Record<string, boolean>>({}); // SMART DEFAULTS: Track touched fields
  const formId = useId();
  const unitSystemGroupId = useId();
  
  const { currency } = useCurrency();
  const currencySymbol = currency?.symbol || "$";

  const groupedInputIds = new Set(inputGroups?.flatMap(g => (g.inputs || g.inputIds || [])) || []);
  const mainInputs = inputs.filter(i => !groupedInputIds.has(i.id));

  // SMART DEFAULTS: Mark field as touched
  const handleFieldBlur = (inputId: string) => {
    setTouched(prev => ({ ...prev, [inputId]: true }));
  };

  // Compute validations - SMART DEFAULTS: Only show if touched
  const validations = useMemo(() => {
    const result: Record<string, ValidationResult> = {};
    inputs.forEach(input => {
      const validation = validateInput(values[input.id], input, currencySymbol, t, locale);
      // SMART DEFAULTS: Only mark as invalid if field was touched
      if (!touched[input.id]) {
        result[input.id] = { isValid: true }; // Don't show error until touched
      } else {
        result[input.id] = validation;
      }
    });
    return result;
  }, [inputs, values, currencySymbol, touched, t, locale]);

  const shouldShowInput = (input: InputConfig): boolean => {
    const showWhen = input.showWhen;
    if (!showWhen) return true;
    
    // Helper function to check a single condition
    const checkCondition = (condition: { field: string; value: string | string[] | number | boolean }): boolean => {
      let fieldValue: unknown;
      if (condition.field === "unitSystem") {
        fieldValue = values.unitSystem ?? unitSystem;
      } else if (condition.field === "currentMode") {
        fieldValue = currentMode;
      } else {
        fieldValue = values[condition.field];
      }
      
      if (Array.isArray(condition.value)) {
        return condition.value.includes(fieldValue as string);
      }
      return fieldValue === condition.value;
    };
    
    // If showWhen is an array, ALL conditions must be true (AND logic)
    if (Array.isArray(showWhen)) {
      return showWhen.every(checkCondition);
    }
    
    // Single condition
    return checkCondition(showWhen);
  };

  const toggleGroup = (groupId: string) => {
    setExpandedGroups(prev => ({ ...prev, [groupId]: !prev[groupId] }));
  };

  const renderMainInputs = () => {
    const visibleInputs = mainInputs.filter(shouldShowInput);
    const rendered: JSX.Element[] = [];
    let i = 0;
    
    while (i < visibleInputs.length) {
      const input = visibleInputs[i];
      const nextInput = visibleInputs[i + 1];
      const errorId = errors[input.id] ? "error-" + input.id : undefined;
      const validation = validations[input.id];
      
      if (input.width === "half" && nextInput?.width === "half") {
        const nextErrorId = errors[nextInput.id] ? "error-" + nextInput.id : undefined;
        const nextValidation = validations[nextInput.id];
        rendered.push(
          <div key={input.id} className="grid grid-cols-1 md:grid-cols-2 gap-4 overflow-hidden">
            <div className="min-w-0">
              <RenderInput input={input} value={values[input.id]} onChange={(v) => onChange(input.id, v)} onBlur={() => handleFieldBlur(input.id)} errorId={errorId} t={t} unitSystem={unitSystem} currencySymbol={currencySymbol} validation={validation} />
            </div>
            <div className="min-w-0">
              <RenderInput input={nextInput} value={values[nextInput.id]} onChange={(v) => onChange(nextInput.id, v)} onBlur={() => handleFieldBlur(nextInput.id)} errorId={nextErrorId} t={t} unitSystem={unitSystem} currencySymbol={currencySymbol} validation={nextValidation} />
            </div>
          </div>
        );
        i += 2;
      } else {
        rendered.push(
          <div key={input.id}>
            <RenderInput input={input} value={values[input.id]} onChange={(v) => onChange(input.id, v)} onBlur={() => handleFieldBlur(input.id)} errorId={errorId} t={t} unitSystem={unitSystem} currencySymbol={currencySymbol} validation={validation} />
          </div>
        );
        i += 1;
      }
    }
    
    return rendered;
  };

  return (
    <form 
      id={formId}
      className="bg-white rounded-2xl border border-slate-200 p-6 md:p-8 shadow-sm"
      onSubmit={(e) => e.preventDefault()}
      noValidate
    >
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold text-slate-900">
          {t("calculator.yourInformation", t("ui.yourInformation", "Your Information"))}
        </h2>
        <button 
          type="button"
          className="p-2 rounded-lg hover:bg-slate-100 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500"
          aria-label={t("buttons.addToFavorites", "Add to favorites")}
        >
          <svg className="w-6 h-6 text-slate-400 hover:text-red-400 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
          </svg>
        </button>
      </div>

      <div className="space-y-5">
        {/* Unit System Toggle */}
        {showUnitSystemToggle && unitSystemOptions && (
          <fieldset role="radiogroup" aria-labelledby={unitSystemGroupId}>
            <legend id={unitSystemGroupId} className="block font-medium text-slate-700 mb-2">
              {t("inputs.unitSystem.label", "Unit System")}
            </legend>
            <div className="grid grid-cols-2 gap-2">
              {unitSystemOptions.map((opt) => (
                <button
                  key={opt.value}
                  type="button"
                  role="radio"
                  aria-checked={unitSystem === opt.value}
                  onClick={() => onUnitSystemChange(opt.value as "metric" | "imperial")}
                  className={"py-3 px-4 rounded-xl text-sm font-medium transition-all focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 " +
                    (unitSystem === opt.value
                      ? "bg-blue-600 text-white shadow-md"
                      : "bg-slate-100 text-slate-700 hover:bg-slate-200")
                  }
                >
                  {t("inputs.unitSystem.options." + opt.value, opt.label)}
                </button>
              ))}
            </div>
          </fieldset>
        )}

        {/* Main Inputs */}
        {renderMainInputs()}

        {/* Input Groups (Collapsible) */}
        {inputGroups?.map((group) => {
          const groupInputs = inputs.filter(i => (group.inputs || group.inputIds || []).includes(i.id));
          const visibleGroupInputs = groupInputs.filter(shouldShowInput);
          
          if (visibleGroupInputs.length === 0) return null;
          
          const isExpanded = expandedGroups[group.id] ?? group.defaultExpanded ?? false;

          return (
            <div key={group.id} className="border-t border-slate-200 pt-4">
              <button
                type="button"
                onClick={() => toggleGroup(group.id)}
                className="w-full flex items-center justify-between py-2 text-left focus:outline-none focus:ring-2 focus:ring-blue-500 rounded-lg"
                aria-expanded={isExpanded}
                aria-controls={`group-content-${group.id}`}
              >
                <span className="font-medium text-slate-700">{t("inputGroups." + group.id + ".title", group.title)}</span>
                <svg 
                  className={"w-5 h-5 text-slate-400 transition-transform " + (isExpanded ? "rotate-180" : "")} 
                  fill="none" 
                  stroke="currentColor" 
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {isExpanded && (
                <div id={`group-content-${group.id}`} className="mt-4 space-y-4">
                  {visibleGroupInputs.map((input) => {
                    const errorId = errors[input.id] ? "error-" + input.id : undefined;
                    const validation = validations[input.id];
                    return (
                      <div key={input.id}>
                        <RenderInput input={input} value={values[input.id]} onChange={(v) => onChange(input.id, v)} onBlur={() => handleFieldBlur(input.id)} errorId={errorId} t={t} unitSystem={unitSystem} currencySymbol={currencySymbol} validation={validation} />
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </form>
  );
}
