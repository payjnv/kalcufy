"use client";

import { useState, useMemo } from "react";

/**
 * ResultsCardV4 - Tarjeta de resultados con formato de moneda
 */

interface ResultConfig {
  id: string;
  type: 'primary' | 'secondary' | 'badge';
  label: string;
  description?: string;
  icon?: string;
  suffix?: string;
  prefix?: string;
  colorMap?: Record<string, { bg: string; text: string; icon?: string }>;
  isCurrency?: boolean;
}

interface CalculatorResults {
  values: Record<string, unknown>;
  formatted: Record<string, string>;
  summary?: string;
  isValid: boolean;
}

interface ResultsCardV4Props {
  results: CalculatorResults | null;
  resultConfigs: ResultConfig[];
  tooltips?: Record<string, string>;
  hasCalculated: boolean;
  isCalculating: boolean;
  title?: string;
  onSave?: () => void;
  saveStatus?: 'idle' | 'saving' | 'saved' | 'error';
  onExportPDF?: () => void;
  onExportCSV?: () => void;
  showActions?: boolean;
}

function Tooltip({ text }: { text: string }) {
  const [show, setShow] = useState(false);
  return (
    <span className="relative inline-block ml-1">
      <button
        onMouseEnter={() => setShow(true)}
        onMouseLeave={() => setShow(false)}
        onFocus={() => setShow(true)}
        onBlur={() => setShow(false)}
        className="w-4 h-4 rounded-full bg-slate-200 text-slate-500 text-xs inline-flex items-center justify-center hover:bg-slate-300 transition-colors"
        aria-label="More information"
      >
        ?
      </button>
      {show && (
        <div className="absolute z-10 bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-2 bg-slate-800 text-white text-xs rounded-lg shadow-lg max-w-xs whitespace-normal">
          {text}
          <div className="absolute top-full left-1/2 -translate-x-1/2 border-4 border-transparent border-t-slate-800" />
        </div>
      )}
    </span>
  );
}

// Format number as currency or with decimals
function formatValue(value: unknown, config: ResultConfig): string {
  if (value === null || value === undefined) return '--';
  
  const num = Number(value);
  if (isNaN(num)) return String(value);
  
  // Check if it's a currency field
  if (config.isCurrency || config.prefix === '$') {
    return num.toLocaleString('en-US', { 
      minimumFractionDigits: 2, 
      maximumFractionDigits: 2 
    });
  }
  
  // For percentages
  if (config.suffix === '%') {
    return num.toFixed(2);
  }
  
  // For large numbers, use locale formatting
  if (Math.abs(num) >= 1000) {
    return num.toLocaleString('en-US', { maximumFractionDigits: 2 });
  }
  
  // For small numbers
  if (Number.isInteger(num)) {
    return num.toString();
  }
  
  return num.toFixed(2);
}

export default function ResultsCardV4({
  results,
  resultConfigs,
  tooltips = {},
  hasCalculated,
  isCalculating,
  title = "Results",
  onSave,
  saveStatus = 'idle',
  onExportPDF,
  onExportCSV,
  showActions = true,
}: ResultsCardV4Props) {
  const { primaryResults, secondaryResults, badgeResults } = useMemo(() => {
    const primary: ResultConfig[] = [];
    const secondary: ResultConfig[] = [];
    const badges: ResultConfig[] = [];
    
    resultConfigs.forEach(config => {
      if (config.type === 'primary') primary.push(config);
      else if (config.type === 'badge') badges.push(config);
      else secondary.push(config);
    });
    
    return { primaryResults: primary, secondaryResults: secondary, badgeResults: badges };
  }, [resultConfigs]);

  const saveButtonText = {
    idle: '💾 Save',
    saving: '...',
    saved: '✓ Saved',
    error: '✗ Error'
  }[saveStatus];

  // Get display value - prefer formatted, fallback to formatting raw value
  const getDisplayValue = (config: ResultConfig): string => {
    if (!results) return '--';
    
    // First try formatted value
    const formatted = results.formatted[config.id];
    if (formatted && formatted !== '--') {
      return formatted;
    }
    
    // Fallback to formatting the raw value
    return formatValue(results.values[config.id], config);
  };

  return (
    <div 
      className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden"
      role="region"
      aria-label="Calculation results"
    >
      {/* Header */}
      <div className="bg-gradient-to-r from-slate-50 to-slate-100 px-5 py-4 border-b border-slate-200">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <span aria-hidden="true">📊</span>
            {title}
          </h2>
          
          {showActions && (
            <div className="flex items-center gap-2">
              {onSave && (
                <button
                  onClick={onSave}
                  disabled={saveStatus === 'saving' || !results?.isValid}
                  className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
                    saveStatus === 'saved'
                      ? 'bg-green-100 text-green-700'
                      : saveStatus === 'error'
                      ? 'bg-red-100 text-red-700'
                      : 'bg-blue-100 text-blue-700 hover:bg-blue-200'
                  } disabled:opacity-50`}
                >
                  {saveButtonText}
                </button>
              )}
              {onExportPDF && (
                <button
                  onClick={onExportPDF}
                  disabled={!results?.isValid}
                  className="px-3 py-1.5 text-xs font-medium rounded-lg bg-slate-100 text-slate-700 hover:bg-slate-200 transition-colors disabled:opacity-50"
                  title="Export as PDF"
                >
                  📄 PDF
                </button>
              )}
              {onExportCSV && (
                <button
                  onClick={onExportCSV}
                  disabled={!results?.isValid}
                  className="px-3 py-1.5 text-xs font-medium rounded-lg bg-slate-100 text-slate-700 hover:bg-slate-200 transition-colors disabled:opacity-50"
                  title="Export as CSV"
                >
                  📊 CSV
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Results Content */}
      <div className="p-5">
        {isCalculating ? (
          <div className="text-center py-8">
            <div className="inline-block w-8 h-8 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin" />
            <p className="text-slate-500 mt-2">Calculating...</p>
          </div>
        ) : !hasCalculated || !results ? (
          <div className="text-center py-8 text-slate-400">
            <span className="text-4xl">📝</span>
            <p className="mt-2">Enter values to see results</p>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Primary Results */}
            {primaryResults.map(config => {
              const value = getDisplayValue(config);
              const tooltip = tooltips[config.id];
              const prefix = config.prefix || (config.isCurrency ? '$' : '');
              
              return (
                <div key={config.id} className="text-center py-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl">
                  <p className="text-sm text-slate-600 mb-1">
                    {config.icon && <span className="mr-1">{config.icon}</span>}
                    {config.label}
                    {tooltip && <Tooltip text={tooltip} />}
                  </p>
                  <p className="text-4xl font-bold text-blue-600">
                    {prefix}{value}{config.suffix}
                  </p>
                  {config.description && (
                    <p className="text-xs text-slate-500 mt-1">{config.description}</p>
                  )}
                </div>
              );
            })}

            {/* Badge Results */}
            {badgeResults.length > 0 && (
              <div className="flex flex-wrap gap-2 justify-center">
                {badgeResults.map(config => {
                  const rawValue = String(results.values[config.id] || '');
                  const colorConfig = config.colorMap?.[rawValue];
                  const bgColor = colorConfig?.bg || 'bg-slate-100';
                  const textColor = colorConfig?.text || 'text-slate-700';
                  const badgeIcon = colorConfig?.icon;
                  const displayValue = getDisplayValue(config);
                  
                  return (
                    <span 
                      key={config.id}
                      className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-medium ${bgColor} ${textColor}`}
                    >
                      {badgeIcon && <span>{badgeIcon}</span>}
                      {displayValue}
                    </span>
                  );
                })}
              </div>
            )}

            {/* Secondary Results */}
            {secondaryResults.length > 0 && (
              <div className="grid grid-cols-2 gap-3 pt-2">
                {secondaryResults.map(config => {
                  const value = getDisplayValue(config);
                  const tooltip = tooltips[config.id];
                  const prefix = config.prefix || (config.isCurrency ? '$' : '');
                  
                  return (
                    <div key={config.id} className="bg-slate-50 rounded-lg p-3 text-center">
                      <p className="text-xs text-slate-500 mb-1">
                        {config.label}
                        {tooltip && <Tooltip text={tooltip} />}
                      </p>
                      <p className="text-lg font-semibold text-slate-800">
                        {prefix}{value}{config.suffix}
                      </p>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Summary */}
            {results.summary && (
              <div className="mt-4 pt-4 border-t border-slate-200">
                <p className="text-sm text-slate-600 text-center italic">
                  {results.summary}
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
