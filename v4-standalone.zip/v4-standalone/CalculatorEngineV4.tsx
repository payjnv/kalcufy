"use client";

/**
 * ============================================================================
 * CALCULATOR ENGINE V4 STANDALONE
 * ============================================================================
 * 100% independent from V3 - uses only native V4 components
 * 
 * Features:
 * - Inline translations (t.en, t.es, t.pt, t.fr, t.de)
 * - Presets (quick scenarios)
 * - Compare panel
 * - Sensitivity analysis
 * - Share with URL values
 * - Lazy loading
 * - Full accessibility
 * ============================================================================
 */

import { useState, useEffect, useCallback, useMemo, useRef } from "react";
import { useSession } from "next-auth/react";
import { useSearchParams } from "next/navigation";
import Header from "@/components/Header";
import Link from "next/link";
import CalculatorSidebar from "@/components/CalculatorSidebar";
import AdBlock from "@/components/ads/AdBlock";
import MobileAdContainer from "@/components/ads/MobileAdContainer";
import SideSkyscraperAds from "@/components/ads/SideSkyscraperAds";

// Import V4 native components
import {
  InputCardV4,
  ResultsCardV4,
  InfoCardV4,
  ReferenceGridV4,
  ProseSectionV4,
  ConsiderationsListV4,
  ExampleSectionV4,
  FAQAccordionV4,
  SourcesSectionV4,
  DistributionBarsV4,
  ModeSelectorV4,
  MobileResultsBarV4,
  RatingShareWidgetV4,
  PresetSelector,
  CompareButton,
  ComparePanel,
  SensitivityChart,
  CollapsibleSection,
  LazySection,
  parseValuesFromUrl,
} from "./components";

import type { 
  CalculatorConfigV4, 
  CalculatorResults,
  SupportedLocale,
  TranslationFn,
  EducationSectionConfig,
} from "./types/engine.types";

// =============================================================================
// DISCLAIMERS
// =============================================================================
const CATEGORY_DISCLAIMERS: Record<string, Record<SupportedLocale, string>> = {
  health: {
    en: "Estimates based on standard equations. Not a substitute for professional medical advice.",
    es: "Estimaciones basadas en ecuaciones estándar. No sustituye el consejo médico profesional.",
    pt: "Estimativas baseadas em equações padrão. Não substitui aconselhamento médico profissional.",
    fr: "Estimations basées sur des équations standard. Ne remplace pas un avis médical professionnel.",
    de: "Schätzungen basieren auf Standardgleichungen. Kein Ersatz für professionelle medizinische Beratung.",
  },
  finance: {
    en: "Results are estimates for informational purposes only. Consult a financial advisor for guidance.",
    es: "Los resultados son estimaciones solo con fines informativos. Consulte a un asesor financiero.",
    pt: "Os resultados são estimativas apenas para fins informativos. Consulte um assessor financeiro.",
    fr: "Les résultats sont des estimations à titre informatif uniquement. Consultez un conseiller financier.",
    de: "Ergebnisse sind nur Schätzungen zu Informationszwecken. Konsultieren Sie einen Finanzberater.",
  },
  math: {
    en: "Results based on standard mathematical formulas. Verify calculations for critical applications.",
    es: "Resultados basados en fórmulas matemáticas estándar. Verifique los cálculos para aplicaciones críticas.",
    pt: "Resultados baseados em fórmulas matemáticas padrão. Verifique os cálculos para aplicações críticas.",
    fr: "Résultats basés sur des formules mathématiques standard. Vérifiez les calculs pour les applications critiques.",
    de: "Ergebnisse basieren auf mathematischen Standardformeln. Überprüfen Sie Berechnungen für kritische Anwendungen.",
  },
  everyday: {
    en: "Results are estimates and may vary. Use as a general guide only.",
    es: "Los resultados son estimaciones y pueden variar. Úselos solo como guía general.",
    pt: "Os resultados são estimativas e podem variar. Use apenas como guia geral.",
    fr: "Les résultats sont des estimations et peuvent varier. Utilisez uniquement comme guide général.",
    de: "Ergebnisse sind Schätzungen und können variieren. Verwenden Sie nur als allgemeine Richtlinie.",
  },
};

// =============================================================================
// HELPERS
// =============================================================================
function initializeValues(
  inputs: CalculatorConfigV4["inputs"], 
  mode?: string
): Record<string, unknown> {
  const values: Record<string, unknown> = {};
  inputs.forEach((input) => {
    if (input.modes && mode && !input.modes.includes(mode)) return;
    values[input.id] = input.defaultValue ?? 
      (input.type === "radio" ? "" : input.type === "checkbox" ? false : 0);
  });
  return values;
}

function initializeUnits(inputs: CalculatorConfigV4["inputs"]): Record<string, string> {
  const units: Record<string, string> = {};
  inputs.forEach((input) => {
    if (input.units && input.units.length > 0) {
      units[input.id] = input.defaultUnit || input.units[0].value;
    }
  });
  return units;
}

function createTranslationFn(
  translations: CalculatorConfigV4["t"]["en"]
): TranslationFn {
  return (key: string, fallback?: string): string => {
    const parts = key.split(".");
    let current: unknown = translations;
    
    for (const part of parts) {
      if (current && typeof current === "object" && part in current) {
        current = (current as Record<string, unknown>)[part];
      } else {
        return fallback || key;
      }
    }
    
    return typeof current === "string" ? current : fallback || key;
  };
}

// =============================================================================
// EDUCATION SECTION RENDERER
// =============================================================================
function RenderEducationSection({ 
  config,
  translations,
  locale,
}: { 
  config: EducationSectionConfig;
  translations: CalculatorConfigV4["t"]["en"]["education"][string];
  locale: SupportedLocale;
}) {
  if (!translations) return null;
  
  switch (config.type) {
    case "prose":
      return (
        <ProseSectionV4
          sectionId={config.id}
          title={translations.title}
          content={translations.content || ""}
          icon={config.icon}
        />
      );
      
    case "list":
      return (
        <ConsiderationsListV4
          sectionId={config.id}
          title={translations.title}
          items={translations.items || []}
          icon={config.icon}
        />
      );
      
    case "code-example":
      return (
        <ExampleSectionV4
          sectionId={config.id}
          title={translations.title}
          description={translations.description}
          examples={translations.examples || []}
          icon={config.icon}
          columns={config.columns}
          background={config.background}
        />
      );
      
    case "cards":
      if (!translations.cards) return null;
      return (
        <div 
          className="bg-white rounded-2xl border border-slate-200 p-6" 
          role="region"
          aria-labelledby={`section-${config.id}`}
        >
          <h3 
            id={`section-${config.id}`}
            className="text-lg font-bold text-slate-900 mb-4"
          >
            {config.icon && <span aria-hidden="true">{config.icon} </span>}
            {translations.title}
          </h3>
          <ul className="space-y-3 text-slate-600">
            {translations.cards.map((card, index) => (
              <li key={index} className="flex items-start gap-2">
                {card.icon && <span className="text-lg mt-0.5">{card.icon}</span>}
                {!card.icon && <span className="text-blue-500 mt-1">•</span>}
                <span>
                  <strong>{card.title}:</strong> {card.description}
                </span>
              </li>
            ))}
          </ul>
        </div>
      );
      
    default:
      return null;
  }
}

// =============================================================================
// MAIN ENGINE COMPONENT
// =============================================================================
export default function CalculatorEngineV4({
  config,
  calculate,
  locale,
}: {
  config: CalculatorConfigV4;
  calculate: (data: {
    values: Record<string, unknown>;
    units: Record<string, string>;
    unitSystem: "metric" | "imperial";
    mode?: string;
  }) => CalculatorResults;
  locale: SupportedLocale;
}) {
  const { data: session } = useSession();
  const searchParams = useSearchParams();
  
  // Get translations for current locale
  const translations = config.t[locale] || config.t.en;
  
  // Create translation function
  const t = useMemo(() => createTranslationFn(translations), [translations]);
  
  // Load values from URL if shared
  const sharedValues = useMemo(
    () => parseValuesFromUrl(searchParams), 
    [searchParams]
  );
  
  // ═══════════════════════════════════════════════════════════════════════════
  // STATE
  // ═══════════════════════════════════════════════════════════════════════════
  const [values, setValues] = useState<Record<string, unknown>>(() => {
    const initial = initializeValues(config.inputs, config.modes?.default);
    return sharedValues ? { ...initial, ...sharedValues } : initial;
  });
  const [units, setUnits] = useState<Record<string, string>>(() => 
    initializeUnits(config.inputs)
  );
  const [unitSystem, setUnitSystem] = useState<"metric" | "imperial">(
    config.unitSystem?.default || "metric"
  );
  const [currentMode, setCurrentMode] = useState<string | undefined>(
    config.modes?.default
  );
  const [results, setResults] = useState<CalculatorResults | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saveStatus, setSaveStatus] = useState<"idle" | "saving" | "saved" | "error">("idle");
  const [showCompare, setShowCompare] = useState(false);
  
  // Tracking refs
  const hasTrackedView = useRef(false);
  const hasTrackedCalculation = useRef(false);

  // ═══════════════════════════════════════════════════════════════════════════
  // CALCULATION
  // ═══════════════════════════════════════════════════════════════════════════
  useEffect(() => {
    if (config.features?.autoCalculate !== false) {
      try {
        const result = calculate({ values, units, unitSystem, mode: currentMode });
        setResults(result);
        
        // Track first calculation
        if (!hasTrackedCalculation.current && result.isValid) {
          hasTrackedCalculation.current = true;
          fetch("/api/track", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              calculatorSlug: translations.slug,
              language: locale,
              type: "CALCULATION"
            })
          }).catch(() => {});
        }
      } catch (e) {
        console.error("Calculation error:", e);
      }
    }
  }, [values, units, unitSystem, currentMode, calculate, config.features?.autoCalculate, translations.slug, locale]);

  // Track page view
  useEffect(() => {
    if (hasTrackedView.current) return;
    hasTrackedView.current = true;
    fetch("/api/track", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        calculatorSlug: translations.slug,
        language: locale,
        type: "VIEW"
      })
    }).catch(() => {});
  }, [translations.slug, locale]);

  // ═══════════════════════════════════════════════════════════════════════════
  // HANDLERS
  // ═══════════════════════════════════════════════════════════════════════════
  const handleValueChange = useCallback((id: string, value: unknown) => {
    setValues(prev => ({ ...prev, [id]: value }));
  }, []);

  const handleUnitChange = useCallback((id: string, unit: string) => {
    setUnits(prev => ({ ...prev, [id]: unit }));
  }, []);

  const handleUnitSystemChange = useCallback((system: "metric" | "imperial") => {
    setUnitSystem(system);
  }, []);

  const handleModeChange = useCallback((mode: string) => {
    setCurrentMode(mode);
    setValues(initializeValues(config.inputs, mode));
  }, [config.inputs]);

  const handlePresetApply = useCallback((presetValues: Record<string, unknown>) => {
    setValues(prev => ({ ...prev, ...presetValues }));
  }, []);

  const saveToHistory = useCallback(async () => {
    if (!session?.user || !results?.isValid) return;
    setSaveStatus("saving");
    try {
      await fetch("/api/history", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          calculatorSlug: translations.slug,
          calculatorName: translations.name,
          category: config.category,
          inputs: values,
          results: results.values,
          language: locale,
        })
      });
      setSaveStatus("saved");
      setTimeout(() => setSaveStatus("idle"), 2000);
    } catch {
      setSaveStatus("error");
    }
  }, [session, results, translations, config.category, values, locale]);

  // Export handlers
  const handleExportPDF = useCallback(async () => {
    const { exportToPDF } = await import("./components/ExportUtils");
    await exportToPDF({
      calculatorName: translations.name,
      calculatorSlug: translations.slug,
      date: new Date().toISOString().split("T")[0],
      locale,
      inputs: config.inputs.map(input => ({
        label: translations.inputs[input.id]?.label || input.id,
        value: String(values[input.id] ?? ""),
      })),
      results: config.results.map(result => ({
        label: translations.results[result.id]?.label || result.id,
        value: results?.formatted[result.id] || "--",
        isPrimary: result.type === "primary",
      })),
      summary: results?.summary || "",
    });
  }, [translations, config, values, results, locale]);

  const handleExportCSV = useCallback(async () => {
    const { exportToCSV } = await import("./components/ExportUtils");
    exportToCSV({
      calculatorName: translations.name,
      calculatorSlug: translations.slug,
      date: new Date().toISOString().split("T")[0],
      locale,
      inputs: config.inputs.map(input => ({
        label: translations.inputs[input.id]?.label || input.id,
        value: String(values[input.id] ?? ""),
      })),
      results: config.results.map(result => ({
        label: translations.results[result.id]?.label || result.id,
        value: results?.formatted[result.id] || "--",
        isPrimary: result.type === "primary",
      })),
      summary: results?.summary || "",
    });
  }, [translations, config, values, results, locale]);

  // ═══════════════════════════════════════════════════════════════════════════
  // DERIVED DATA
  // ═══════════════════════════════════════════════════════════════════════════
  const disclaimer = translations.disclaimer || 
    CATEGORY_DISCLAIMERS[config.category]?.[locale] || 
    CATEGORY_DISCLAIMERS[config.category]?.en || "";
  
  const tooltips = translations.tooltips || {};
  
  const presetsEnabled = config.features?.presetsEnabled !== false && 
    config.presets && config.presets.length > 0;
  const compareEnabled = config.features?.compareEnabled === true;
  const sensitivityEnabled = config.features?.sensitivityEnabled === true && 
    config.sensitivity;

  // Group education sections by type for layout
  const educationSections = config.educationSections || [];
  const cardSections = educationSections.filter(s => s.type === "cards");
  const listSections = educationSections.filter(s => s.type === "list");
  const exampleSections = educationSections.filter(s => s.type === "code-example");
  const proseSections = educationSections.filter(s => s.type === "prose");

  // ═══════════════════════════════════════════════════════════════════════════
  // RENDER
  // ═══════════════════════════════════════════════════════════════════════════
  return (
    <>
      {/* Skip Link */}
      <a 
        href="#calculator-main" 
        className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:z-50 focus:px-4 focus:py-2 focus:bg-blue-600 focus:text-white focus:rounded-lg"
      >
        {t("ui.skipToCalculator", "Skip to calculator")}
      </a>
      
      {/* Live Region for Screen Readers */}
      <div role="status" aria-live="polite" aria-atomic="true" className="sr-only">
        {results?.summary || ""}
      </div>

      <Header />
      <SideSkyscraperAds />
      
      <main id="calculator-main" role="main" className="md:min-h-screen bg-gradient-to-b from-slate-50 to-white pb-24 lg:pb-8">
        {/* Hero Section */}
        <section className="bg-gradient-to-b from-blue-50 to-white pt-4 pb-0 md:py-6">
          <div className="container mx-auto px-4 max-w-6xl">
            {/* Breadcrumbs */}
            <nav aria-label="Breadcrumb" className="flex items-center gap-2 text-sm text-slate-600 mb-4">
              <Link href={`/${locale}`} className="hover:text-blue-600 transition-colors">
                {t("common.home", "Home")}
              </Link>
              <span className="text-slate-400">/</span>
              <Link href={`/${locale}/calculators`} className="hover:text-blue-600 transition-colors">
                {t("common.calculators", "Calculators")}
              </Link>
              <span className="text-slate-400">/</span>
              <span className="text-slate-900 font-medium">
                {translations.breadcrumb || translations.name}
              </span>
            </nav>
            
            {/* Title Row */}
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div>
                <h1 className="text-xl md:text-2xl lg:text-3xl font-bold text-slate-900">
                  {translations.name}
                </h1>
                <p className="text-slate-600 mt-1">{translations.subtitle}</p>
              </div>
              
              <RatingShareWidgetV4
                calculatorSlug={translations.slug}
                calculatorName={translations.name}
                calculatorId={config.id}
                variant="hero"
                values={values}
                results={results?.values}
                unitSystem={unitSystem}
                locale={locale}
                t={t}
              />
            </div>
          </div>
        </section>

        {/* Mobile Ad */}
        {config.ads?.mobileHero && (
          <MobileAdContainer slot="calculator-mobile-hero" position="top" />
        )}

        {/* Main Calculator Section */}
        <section className="py-4">
          <div className="container mx-auto px-4 max-w-6xl">
            <div className="grid lg:grid-cols-2 gap-8">
              {/* Left: Inputs */}
              <div className="space-y-6">
                {/* Presets */}
                {presetsEnabled && (
                  <PresetSelector
                    presets={config.presets!}
                    translations={translations.presets || {}}
                    onApply={handlePresetApply}
                    title={t("ui.quickStart", "Quick Start:")}
                  />
                )}

                {/* Mode Selector */}
                {config.modes?.enabled && (
                  <ModeSelectorV4
                    modes={config.modes.options.map(m => ({
                      id: m.id,
                      label: translations.modes?.[m.id] || m.id,
                      icon: m.icon,
                    }))}
                    currentMode={currentMode || config.modes.default}
                    onChange={handleModeChange}
                  />
                )}

                {/* Input Card */}
                <InputCardV4
                  inputs={config.inputs.map(input => ({
                    ...input,
                    label: translations.inputs[input.id]?.label || input.id,
                    helpText: translations.inputs[input.id]?.helpText,
                    suffix: translations.inputs[input.id]?.suffix || input.unitOptions?.[unitSystem]?.suffix,
                    placeholder: translations.inputs[input.id]?.placeholder,
                    options: input.options?.map(opt => ({
                      ...opt,
                      label: translations.inputs[input.id]?.options?.[opt.value] || opt.value,
                    })),
                  }))}
                  inputGroups={config.inputGroups}
                  values={values}
                  units={units}
                  unitSystem={unitSystem}
                  errors={errors}
                  onChange={handleValueChange}
                  onUnitChange={handleUnitChange}
                  onUnitSystemChange={handleUnitSystemChange}
                  t={t}
                  showUnitSystemToggle={config.unitSystem?.enabled}
                  currentMode={currentMode}
                />

                {/* Compare Button */}
                {compareEnabled && (
                  <CompareButton 
                    onClick={() => setShowCompare(true)} 
                    label={t("ui.compare", "Compare Scenarios")}
                  />
                )}
              </div>

              {/* Right: Results */}
              <div className="space-y-6">
                {/* Results Card */}
                <ResultsCardV4
                  results={results}
                  resultConfigs={config.results.map(r => ({
                    ...r,
                    label: translations.results[r.id]?.label || r.id,
                    description: translations.results[r.id]?.description,
                  }))}
                  tooltips={tooltips}
                  hasCalculated={true}
                  isCalculating={false}
                  title={t("ui.results", "Results")}
                  onSave={config.features?.saveHistory !== false ? saveToHistory : undefined}
                  saveStatus={saveStatus}
                  onExportPDF={config.features?.exportPDF !== false ? handleExportPDF : undefined}
                  onExportCSV={config.features?.exportCSV !== false ? handleExportCSV : undefined}
                  showActions={true}
                />

                {/* Sensitivity Chart */}
                {sensitivityEnabled && config.sensitivity && (
                  <SensitivityChart
                    config={config.sensitivity}
                    currentValues={values}
                    calculate={calculate}
                    inputLabel={translations.inputs[config.sensitivity.inputId]?.label}
                    resultLabel={translations.results[config.sensitivity.resultId]?.label}
                    title={t("ui.sensitivity", "Sensitivity Analysis")}
                  />
                )}

                {/* Info Cards */}
                {config.infoCards?.map((card) => {
                  const cardT = translations.infoCards[card.id];
                  if (!cardT) return null;
                  
                  return (
                    <InfoCardV4
                      key={card.id}
                      cardId={card.id}
                      title={cardT.title}
                      items={Array.isArray(cardT.items) 
                        ? cardT.items.map((item, i) => ({
                            label: typeof item === "string" ? item : item.label,
                            valueKey: typeof item === "object" ? item.valueKey : card.items[i]?.valueKey,
                            icon: card.items[i]?.icon,
                            color: card.items[i]?.color,
                          }))
                        : []
                      }
                      type={card.type}
                      icon={card.icon}
                      columns={card.columns}
                      results={results}
                    />
                  );
                })}

                {/* Reference Data */}
                {config.referenceData?.map((ref) => {
                  const refT = translations.referenceData[ref.id];
                  if (!refT) return null;
                  
                  return (
                    <ReferenceGridV4
                      key={ref.id}
                      refId={ref.id}
                      title={refT.title}
                      items={refT.items}
                      icon={ref.icon}
                      columns={ref.columns}
                    />
                  );
                })}

                {/* Rating Widget */}
                <RatingShareWidgetV4
                  calculatorSlug={translations.slug}
                  calculatorName={translations.name}
                  calculatorId={config.id}
                  variant="default"
                  values={values}
                  results={results?.values}
                  unitSystem={unitSystem}
                  locale={locale}
                  t={t}
                />

                {/* Disclaimer */}
                {disclaimer && (
                  <p className="text-xs text-slate-400 text-center italic px-4">
                    {disclaimer}
                  </p>
                )}
              </div>
            </div>
          </div>
        </section>

        {/* Desktop Ad After Results */}
        {config.ads?.sidebar !== false && (
          <section className="py-2 hidden md:block">
            <div className="container mx-auto px-4 max-w-6xl">
              <AdBlock slot="calculator-after-results" />
            </div>
          </section>
        )}

        {/* Mobile: Collapsible Sections (Lazy Loaded) */}
        <div className="md:hidden">
          <LazySection minHeight="400px">
            <section className="py-4">
              <div className="container mx-auto px-4 max-w-6xl space-y-3">
                {/* Card Sections */}
                {cardSections.map((section) => {
                  const sectionT = translations.education[section.id];
                  if (!sectionT) return null;
                  return (
                    <CollapsibleSection 
                      key={section.id}
                      title={sectionT.title}
                      icon={section.icon}
                    >
                      <RenderEducationSection 
                        config={section} 
                        translations={sectionT}
                        locale={locale}
                      />
                    </CollapsibleSection>
                  );
                })}
                
                {/* List Sections */}
                {listSections.map((section) => {
                  const sectionT = translations.education[section.id];
                  if (!sectionT) return null;
                  return (
                    <CollapsibleSection 
                      key={section.id}
                      title={sectionT.title}
                      icon={section.icon}
                    >
                      <RenderEducationSection 
                        config={section} 
                        translations={sectionT}
                        locale={locale}
                      />
                    </CollapsibleSection>
                  );
                })}
                
                {/* Example Sections */}
                {exampleSections.map((section) => {
                  const sectionT = translations.education[section.id];
                  if (!sectionT) return null;
                  return (
                    <CollapsibleSection 
                      key={section.id}
                      title={sectionT.title}
                      icon={section.icon}
                    >
                      <RenderEducationSection 
                        config={section} 
                        translations={sectionT}
                        locale={locale}
                      />
                    </CollapsibleSection>
                  );
                })}
                
                {/* Prose Sections */}
                {proseSections.map((section) => {
                  const sectionT = translations.education[section.id];
                  if (!sectionT) return null;
                  return (
                    <CollapsibleSection 
                      key={section.id}
                      title={sectionT.title}
                      icon={section.icon}
                    >
                      <RenderEducationSection 
                        config={section} 
                        translations={sectionT}
                        locale={locale}
                      />
                    </CollapsibleSection>
                  );
                })}
                
                {/* Sources */}
                {config.references.length > 0 && (
                  <CollapsibleSection 
                    title={t("sources.title", "Sources & References")}
                    icon="📚"
                  >
                    <SourcesSectionV4
                      title={t("sources.title", "Sources & References")}
                      references={config.references}
                    />
                  </CollapsibleSection>
                )}
                
                {/* FAQs */}
                {translations.faqs.length > 0 && (
                  <CollapsibleSection 
                    title={t("faq.title", "Frequently Asked Questions")}
                    icon="❓"
                  >
                    <FAQAccordionV4
                      title={t("faq.title", "Frequently Asked Questions")}
                      faqs={translations.faqs}
                      calculatorSlug={translations.slug}
                    />
                  </CollapsibleSection>
                )}
              </div>
            </section>
          </LazySection>
        </div>

        {/* Desktop: Full Layout */}
        <div className="hidden md:block">
          {/* Grid Sections (Cards + List) */}
          {(cardSections.length > 0 || listSections.length > 0) && (
            <section className="py-8">
              <div className="container mx-auto px-4 max-w-6xl">
                <div className="grid md:grid-cols-2 gap-6">
                  {[...cardSections, ...listSections].slice(0, 2).map((section) => {
                    const sectionT = translations.education[section.id];
                    if (!sectionT) return null;
                    return (
                      <RenderEducationSection 
                        key={section.id}
                        config={section} 
                        translations={sectionT}
                        locale={locale}
                      />
                    );
                  })}
                </div>
              </div>
            </section>
          )}

          {/* Full Width: Examples */}
          {exampleSections.map((section) => {
            const sectionT = translations.education[section.id];
            if (!sectionT) return null;
            return (
              <RenderEducationSection 
                key={section.id}
                config={section} 
                translations={sectionT}
                locale={locale}
              />
            );
          })}

          {/* Prose + Sidebar */}
          {(proseSections.length > 0 || translations.faqs.length > 0) && (
            <section className="py-12">
              <div className="container mx-auto px-4 max-w-6xl">
                <div className="grid lg:grid-cols-3 gap-8">
                  <div className="lg:col-span-2 space-y-8">
                    {/* Prose Sections */}
                    {proseSections.map((section) => {
                      const sectionT = translations.education[section.id];
                      if (!sectionT) return null;
                      return (
                        <RenderEducationSection 
                          key={section.id}
                          config={section} 
                          translations={sectionT}
                          locale={locale}
                        />
                      );
                    })}
                    
                    {/* Sources */}
                    {config.references.length > 0 && (
                      <SourcesSectionV4
                        title={t("sources.title", "Sources & References")}
                        references={config.references}
                      />
                    )}
                    
                    {/* FAQs */}
                    {translations.faqs.length > 0 && (
                      <FAQAccordionV4
                        title={t("faq.title", "Frequently Asked Questions")}
                        faqs={translations.faqs}
                        calculatorSlug={translations.slug}
                      />
                    )}
                  </div>
                  
                  {/* Sidebar */}
                  <aside>
                    <CalculatorSidebar
                      currentCalculator={translations.slug}
                      category={config.sidebar?.category || config.category}
                      showCTA={config.sidebar?.showCTA !== false}
                    />
                  </aside>
                </div>
              </div>
            </section>
          )}
        </div>

        {/* Bottom Ad */}
        {config.ads?.bottom !== false && (
          <section className="py-8">
            <div className="container mx-auto px-4 max-w-4xl">
              <AdBlock slot="calculator-bottom" />
            </div>
          </section>
        )}
      </main>

      {/* Mobile Results Bar */}
      <MobileResultsBarV4
        results={results}
        hasCalculated={true}
        primaryLabel={translations.results[config.results[0]?.id]?.label || "Result"}
        primaryValue={results?.formatted[config.results[0]?.id] || "--"}
        primaryUnit={config.results[0]?.suffix}
        onSave={config.features?.saveHistory !== false ? saveToHistory : undefined}
        saveStatus={saveStatus}
        isLoggedIn={!!session}
        t={t}
      />
      
      <MobileAdContainer slot="calculator-mobile-bottom" position="bottom" />

      {/* Compare Panel Modal */}
      {compareEnabled && (
        <ComparePanel
          isOpen={showCompare}
          onClose={() => setShowCompare(false)}
          scenarioA={values}
          scenarioB={values}
          resultConfigs={config.results.map(r => ({
            id: r.id,
            type: r.type,
            label: translations.results[r.id]?.label || r.id,
          }))}
          calculate={calculate}
          labels={{
            title: t("ui.compareTitle", "Compare Scenarios"),
            close: t("ui.close", "Close"),
          }}
        />
      )}
    </>
  );
}
