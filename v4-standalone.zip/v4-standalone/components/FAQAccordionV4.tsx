"use client";

import { useState } from "react";

/**
 * FAQAccordionV4 - Acordeón de preguntas frecuentes
 * Diseño idéntico a V3, incluye Schema.org para SEO
 */

interface FAQItem {
  question: string;
  answer: string;
}

interface FAQAccordionV4Props {
  title: string;
  faqs: FAQItem[];
  calculatorSlug: string;
  defaultOpenIndex?: number;
}

export default function FAQAccordionV4({ 
  title,
  faqs, 
  calculatorSlug,
  defaultOpenIndex = 0
}: FAQAccordionV4Props) {
  const [openIndex, setOpenIndex] = useState<number | null>(defaultOpenIndex);

  if (!faqs || faqs.length === 0) return null;

  // Generate Schema.org FAQPage JSON-LD
  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": faqs.map(faq => ({
      "@type": "Question",
      "name": faq.question,
      "acceptedAnswer": {
        "@type": "Answer",
        "text": faq.answer
      }
    }))
  };

  return (
    <div 
      className="bg-white rounded-2xl border border-slate-200 p-6"
      role="region"
      aria-labelledby="faq-section"
    >
      {/* Schema.org JSON-LD for SEO */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}
      />
      
      <h2 
        id="faq-section"
        className="text-xl font-bold text-slate-900 mb-6 flex items-center gap-2"
      >
        <span aria-hidden="true">❓</span>
        {title}
      </h2>
      
      <div className="space-y-3" role="list">
        {faqs.map((faq, index) => {
          const isOpen = openIndex === index;
          const itemId = `faq-${calculatorSlug}-${index}`;
          
          return (
            <div 
              key={index} 
              className="border border-slate-200 rounded-xl overflow-hidden transition-shadow hover:shadow-sm"
              role="listitem"
            >
              <button
                id={`${itemId}-button`}
                onClick={() => setOpenIndex(isOpen ? null : index)}
                className="w-full px-4 py-4 text-left flex justify-between items-center hover:bg-slate-50 transition-colors"
                aria-expanded={isOpen}
                aria-controls={`${itemId}-panel`}
              >
                <span className="font-medium text-slate-800 pr-4">
                  {faq.question}
                </span>
                <svg
                  className={`w-5 h-5 text-slate-400 flex-shrink-0 transition-transform duration-200 ${
                    isOpen ? 'rotate-180' : ''
                  }`}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                >
                  <path 
                    strokeLinecap="round" 
                    strokeLinejoin="round" 
                    strokeWidth={2} 
                    d="M19 9l-7 7-7-7" 
                  />
                </svg>
              </button>
              
              <div
                id={`${itemId}-panel`}
                role="region"
                aria-labelledby={`${itemId}-button`}
                className={`
                  transition-all duration-200 ease-out overflow-hidden
                  ${isOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'}
                `}
              >
                <div className="px-4 pb-4 text-slate-600 leading-relaxed border-t border-slate-100 pt-3">
                  {faq.answer}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
