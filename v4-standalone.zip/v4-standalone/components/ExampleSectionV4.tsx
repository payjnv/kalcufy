"use client";

/**
 * ExampleSectionV4 - Sección de ejemplos de cálculo
 * Diseño idéntico a V3, lee traducciones directamente
 */

interface CodeExample {
  title: string;
  steps: string[];
  result: string;
}

interface ExampleSectionV4Props {
  sectionId: string;
  title: string;
  description?: string;
  examples: CodeExample[];
  icon?: string;
  columns?: 1 | 2 | 3;
  background?: 'white' | 'slate';
}

export default function ExampleSectionV4({ 
  sectionId,
  title, 
  description,
  examples, 
  icon,
  columns = 2,
  background = 'white'
}: ExampleSectionV4Props) {
  if (!examples || examples.length === 0) return null;

  const bgClass = background === 'slate' ? 'bg-slate-50' : 'bg-white';
  const gridCols: Record<number, string> = {
    1: 'grid-cols-1',
    2: 'md:grid-cols-2',
    3: 'md:grid-cols-3',
  };

  return (
    <section 
      className={`${bgClass} py-8`}
      role="region"
      aria-labelledby={`examples-${sectionId}`}
    >
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="bg-white rounded-2xl border border-slate-200 p-6">
          <h3 
            id={`examples-${sectionId}`}
            className="text-lg font-bold text-slate-900 mb-2"
          >
            {icon && <span aria-hidden="true">{icon} </span>}
            {title}
          </h3>
          
          {description && (
            <p className="text-slate-600 mb-4">{description}</p>
          )}
          
          <div className={`grid ${gridCols[columns]} gap-4`}>
            {examples.map((example, index) => (
              <div 
                key={index} 
                className="bg-slate-900 text-slate-100 rounded-xl p-4 font-mono text-sm"
              >
                <p className="text-blue-400 font-semibold mb-3 text-base">
                  {example.title}
                </p>
                <div className="space-y-1">
                  {example.steps.map((step, i) => (
                    <p key={i} className="text-slate-300 leading-relaxed">
                      {step}
                    </p>
                  ))}
                </div>
                <div className="mt-3 pt-3 border-t border-slate-700">
                  <p className="text-green-400 font-semibold">
                    {example.result}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
