// ============================================================================
// ENGINE V4 STANDALONE - TYPES
// ============================================================================
// Completely independent from V3 - no imports from V3
// ============================================================================

export type SupportedLocale = 'en' | 'es' | 'pt' | 'fr' | 'de';

// ─────────────────────────────────────────────────────────────────────────────
// TRANSLATION TYPES
// ─────────────────────────────────────────────────────────────────────────────
export interface InputTranslation {
  label: string;
  helpText?: string;
  suffix?: string;
  prefix?: string;
  placeholder?: string;
  options?: Record<string, string>;
}

export interface ResultTranslation {
  label: string;
  description?: string;
}

export interface InfoCardTranslation {
  title: string;
  items: string[] | Array<{ label: string; valueKey?: string }>;
}

export interface ReferenceDataTranslation {
  title: string;
  items: Array<{ label: string; value: string }>;
}

export interface FAQTranslation {
  question: string;
  answer: string;
}

export interface EducationSectionTranslation {
  title: string;
  content?: string;
  description?: string;
  items?: Array<{ text: string; type?: 'warning' | 'info' | 'success' | 'error' }>;
  cards?: Array<{ title: string; description: string; icon?: string }>;
  examples?: Array<{
    title: string;
    steps: string[];
    result: string;
  }>;
}

export interface PresetTranslation {
  label: string;
  description?: string;
}

export interface CalculatorTranslations {
  name: string;
  slug: string;
  subtitle: string;
  breadcrumb?: string;
  
  seo: {
    title: string;
    description: string;
    keywords: string[];
  };
  
  ui?: {
    yourInformation?: string;
    calculate?: string;
    reset?: string;
    results?: string;
    loading?: string;
    quickStart?: string;
    compare?: string;
    compareTitle?: string;
    sensitivity?: string;
    close?: string;
    save?: string;
    saved?: string;
    error?: string;
    exportPDF?: string;
    exportCSV?: string;
  };
  
  common?: {
    home?: string;
    calculators?: string;
    reviews?: string;
  };
  
  inputs: Record<string, InputTranslation>;
  results: Record<string, ResultTranslation>;
  infoCards: Record<string, InfoCardTranslation>;
  referenceData: Record<string, ReferenceDataTranslation>;
  education: Record<string, EducationSectionTranslation>;
  faqs: FAQTranslation[];
  
  presets?: Record<string, PresetTranslation>;
  tooltips?: Record<string, string>;
  modes?: Record<string, string>;
  disclaimer?: string;
}

// ─────────────────────────────────────────────────────────────────────────────
// INPUT TYPES
// ─────────────────────────────────────────────────────────────────────────────
export type InputType = 
  | 'number'
  | 'slider'
  | 'radio'
  | 'select'
  | 'checkbox'
  | 'text'
  | 'date'
  | 'currency'
  | 'percentage';

export interface InputOption {
  value: string;
  icon?: string;
}

export interface UnitOption {
  value: string;
  label?: string;
  conversionFactor?: number;
}

export interface ShowWhenCondition {
  field: string;
  value: string | string[] | number | boolean;
}

export interface InputConfig {
  id: string;
  type: InputType;
  required?: boolean;
  defaultValue?: string | number | boolean;
  min?: number;
  max?: number;
  step?: number;
  options?: InputOption[];
  units?: UnitOption[];
  defaultUnit?: string;
  width?: 'full' | 'half' | 'third' | 'quarter';
  showWhen?: ShowWhenCondition;
  modes?: string[];
  showSlider?: boolean;
  unitOptions?: {
    imperial: { suffix: string; min?: number; max?: number; default?: number };
    metric: { suffix: string; min?: number; max?: number; default?: number };
  };
  isCurrency?: boolean;
}

export interface InputGroup {
  id: string;
  inputs: string[];
  collapsible?: boolean;
  defaultExpanded?: boolean;
  icon?: string;
}

// ─────────────────────────────────────────────────────────────────────────────
// RESULT TYPES
// ─────────────────────────────────────────────────────────────────────────────
export type ResultType = 'primary' | 'secondary' | 'badge';

export interface ResultConfig {
  id: string;
  type: ResultType;
  format?: 'number' | 'currency' | 'percentage' | 'text' | 'date';
  decimals?: number;
  suffix?: string;
  prefix?: string;
  icon?: string;
  colorMap?: Record<string, { bg: string; text: string; icon?: string }>;
  showWhen?: ShowWhenCondition;
  isCurrency?: boolean;
}

// ─────────────────────────────────────────────────────────────────────────────
// INFO CARDS & REFERENCE DATA
// ─────────────────────────────────────────────────────────────────────────────
export interface InfoCardItem {
  valueKey?: string;
  icon?: string;
  color?: 'default' | 'green' | 'blue' | 'amber' | 'red';
  isCurrency?: boolean;
}

export interface InfoCardConfig {
  id: string;
  icon?: string;
  type: 'list' | 'grid' | 'horizontal';
  items: InfoCardItem[];
  columns?: number;
}

export interface ReferenceDataConfig {
  id: string;
  icon?: string;
  columns?: 2 | 3 | 4;
}

// ─────────────────────────────────────────────────────────────────────────────
// EDUCATION SECTIONS
// ─────────────────────────────────────────────────────────────────────────────
export type SectionType = 'prose' | 'cards' | 'list' | 'code-example';

export interface EducationSectionConfig {
  id: string;
  type: SectionType;
  icon?: string;
  columns?: 1 | 2 | 3;
  background?: 'white' | 'slate';
}

// ─────────────────────────────────────────────────────────────────────────────
// REFERENCES
// ─────────────────────────────────────────────────────────────────────────────
export interface Reference {
  authors: string;
  title: string;
  source: string;
  year?: string;
  url?: string;
}

// ─────────────────────────────────────────────────────────────────────────────
// MODES
// ─────────────────────────────────────────────────────────────────────────────
export interface ModeOption {
  id: string;
  icon?: string;
}

export interface ModesConfig {
  enabled: boolean;
  options: ModeOption[];
  default: string;
}

// ─────────────────────────────────────────────────────────────────────────────
// PRESETS
// ─────────────────────────────────────────────────────────────────────────────
export interface PresetConfig {
  id: string;
  icon?: string;
  values: Record<string, unknown>;
}

// ─────────────────────────────────────────────────────────────────────────────
// SENSITIVITY ANALYSIS
// ─────────────────────────────────────────────────────────────────────────────
export interface SensitivityConfig {
  inputId: string;
  resultId: string;
  steps?: number;
  rangePercent?: number;
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN CALCULATOR CONFIG V4 STANDALONE
// ─────────────────────────────────────────────────────────────────────────────
export interface CalculatorConfigV4 {
  id: string;
  category: 'health' | 'finance' | 'math' | 'everyday';
  icon: string;
  version?: string;
  
  // TRANSLATIONS (INLINE)
  t: {
    en: CalculatorTranslations;
    es: CalculatorTranslations;
    pt?: CalculatorTranslations;
    fr?: CalculatorTranslations;
    de?: CalculatorTranslations;
  };
  
  // STRUCTURE
  hero: {
    badge?: string;
    rating?: { average: number; count: number };
    highlights?: string[];
  };
  
  unitSystem?: {
    enabled: boolean;
    default: 'metric' | 'imperial';
  };
  
  modes?: ModesConfig;
  
  inputs: InputConfig[];
  inputGroups?: InputGroup[];
  
  results: ResultConfig[];
  
  infoCards?: InfoCardConfig[];
  referenceData?: ReferenceDataConfig[];
  educationSections?: EducationSectionConfig[];
  
  references: Reference[];
  
  sidebar?: {
    showSearch?: boolean;
    showRelatedCalculators?: boolean;
    showCTA?: boolean;
    category?: string;
  };
  
  features?: {
    autoCalculate?: boolean;
    exportPDF?: boolean;
    exportCSV?: boolean;
    shareResults?: boolean;
    saveHistory?: boolean;
    compareEnabled?: boolean;
    sensitivityEnabled?: boolean;
    presetsEnabled?: boolean;
  };
  
  presets?: PresetConfig[];
  sensitivity?: SensitivityConfig;
  
  relatedCalculators?: string[];
  
  ads?: {
    mobileHero?: boolean;
    sidebar?: boolean;
    mobileContent?: boolean;
    bottom?: boolean;
    afterResults?: boolean;
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// CALCULATOR RESULTS
// ─────────────────────────────────────────────────────────────────────────────
export interface CalculatorResults {
  values: Record<string, unknown>;
  formatted: Record<string, string>;
  summary?: string;
  isValid: boolean;
  metadata?: {
    tableData?: Array<Record<string, unknown>>;
    distribution?: Array<{ id: string; label: string; value: number; max?: number }>;
    [key: string]: unknown;
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// CALCULATE FUNCTION TYPE
// ─────────────────────────────────────────────────────────────────────────────
export type CalculateFn = (data: {
  values: Record<string, unknown>;
  units: Record<string, string>;
  unitSystem: 'metric' | 'imperial';
  mode?: string;
}) => CalculatorResults;

// ─────────────────────────────────────────────────────────────────────────────
// TRANSLATION FUNCTION TYPE
// ─────────────────────────────────────────────────────────────────────────────
export type TranslationFn = (key: string, fallback?: string) => string;
